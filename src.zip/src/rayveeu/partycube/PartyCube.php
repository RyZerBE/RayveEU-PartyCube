<?php

declare(strict_types=1);

namespace rayveeu\partycube;

use lookup\ServerSetting;
use minigame\map\MapManager;
use minigame\Minigame;
use minigame\player\MinigamePlayerType;
use minigame\player\PlayerCache;
use minigame\util\GameSettings;
use pocketmine\player\Player;
use pocketmine\Server;
use rayveeu\partycube\command\ForceMinigameCommand;
use rayveeu\partycube\command\ForceStartCommand;
use rayveeu\partycube\command\HelpSetupCommand;
use rayveeu\partycube\map\LobbyMap;
use rayveeu\partycube\minigame\MinigameManager;
use rayveeu\partycube\registry\Registry;
use rayveeu\partycube\state\CountdownState;
use rayveeu\partycube\state\IngameState;
use rayveeu\partycube\state\phase\Phase;
use rayveeu\partycube\state\RestartState;
use rayveeu\partycube\state\WaitingState;
use rayveeu\partycube\minigame\Minigame as PCMinigame;
use rayveeu\partycube\util\ranking\HighestPointsRanking;
use rayveeu\partycube\util\ranking\Ranking;

class PartyCube extends Minigame{
    public static ?string $showcaseGame = null;

    protected function onEnable(): void{
        parent::onEnable();

        Registry::init();

        $map = new LobbyMap();
        $map->load(fn() => null);
        MapManager::register($map);
        MapManager::setCurrentMap($map);

        Server::getInstance()->getCommandMap()->registerAll("partycube", [
            new ForceMinigameCommand(),
            new ForceStartCommand(),
            new HelpSetupCommand(),
        ]);

        PlayerCache::addCacheAndLoadClosure("points", function(Player $player): int {
            return MinigamePlayerType::get($player)->getPoints()->get();
        }, function(Player $player, int $points): void {
            MinigamePlayerType::get($player)->getPoints()->set($points);
        });

        $this->getEventListener()->registerHandler(function(): ?PCMinigame{
            return MinigameManager::getRunningMinigame();
        });
        $this->getEventListener()->registerHandler(function(): ?Phase {
            $state = $this->getState();
            if(!$state instanceof IngameState) {
                return null;
            }
            return $state->getPhase();
        });
    }

    public function getMinigame(): string{
        return "PartyCube";
    }

    public function getMaxPlayers(): int{
        return 12;
    }

    public function getMinimumPlayers(): int{
        return $this->isForceStart() ? 2 : 4;
    }

    public function getInitialStates(): array{
        return [
            new WaitingState(),
            new CountdownState(),
            new IngameState(),
            new RestartState(),
        ];
    }

    public function getCurrentRanking(): Ranking {
        $ranking = new HighestPointsRanking();
        foreach(self::getInstance()->getSessions() as $session) {
            $player = $session->getPlayer();
            $ranking->getPoints($player)->set(MinigamePlayerType::get($player)->getPoints()->get());
        }
        return $ranking;
    }

    public function handleSettings(GameSettings $settings): void{
        $game = MinigameManager::getByName($settings->getString(ServerSetting::SHOWCASE_GAME, ""));
        if($game !== null) {
            self::$showcaseGame = $game::class;
        }
    }
}