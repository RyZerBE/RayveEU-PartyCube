<?php

declare(strict_types=1);

namespace rayveeu\partycube\animation;

use rayveeu\essentials\animation\Animation;
use rayveeu\essentials\util\TitleFormat;
use rayveeu\partycube\minigame\MinigameManager;

class BroadcastMinigameAnimation extends Animation{
    public function tick(int $tick): void{
        if($tick === 20) {
            $this->broadcastTitle(TitleFormat::CENTER_RAISED, MinigameManager::getCurrentNullSafe()->getName(), [], 50);
            $this->broadcastSound("mob.allay.idle_holding", 0.7);
        }

        //TODO

        if($tick >= 60) {
            $this->finish();
        }
    }
}