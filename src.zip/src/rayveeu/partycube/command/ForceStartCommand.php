<?php

declare(strict_types=1);

namespace rayveeu\partycube\command;

use pocketmine\command\CommandSender;
use pocketmine\player\Player;
use rayveeu\essentials\command\BaseCommand;
use rayveeu\partycube\PartyCube;
use rayveeu\partycube\state\CountdownState;

class ForceStartCommand extends BaseCommand{
    public function __construct(){
        parent::__construct("forcestart", "Force game start", null, ["start"]);
        $this->setPermission("default.op");
    }

    public function execute(CommandSender $sender, string $commandLabel, array $args): void{
        if(!$sender instanceof Player) {
            return;
        }
        PartyCube::getInstance()->setForceStart(!PartyCube::getInstance()->isForceStart());
        $state = PartyCube::getInstance()->getState();
        if($state instanceof CountdownState) {
            $state->getCountdown()->set(11);
        }
    }
}