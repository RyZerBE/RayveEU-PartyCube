<?php

declare(strict_types=1);

namespace rayveeu\partycube\command;

use pocketmine\command\CommandSender;
use pocketmine\command\utils\CommandException;
use pocketmine\lang\Translatable;
use pocketmine\player\Player;
use rayveeu\essentials\command\BaseCommand;
use rayveeu\essentials\util\math\Math;
use rayveeu\essentials\util\SpawnPosition;

class HelpSetupCommand extends BaseCommand{
    public function __construct(){
        parent::__construct("helpsetup");
        $this->setPermission("command.helpsetup.use");
    }

    public function execute(CommandSender $sender, string $commandLabel, array $args): void{
        if(!$sender instanceof Player) {
            return;
        }
        $location = $sender->getLocation();

        echo "new SpawnPosition(".($location->getFloorX() + 0.5).", ".($location->getFloorY() + 0.5).", ".($location->getFloorZ() + 0.5).", ".Math::lowestDiff($location->getYaw(), [0, 45, 90, 135, 180, 225, 270, 315, 360])->value."),";
    }
}