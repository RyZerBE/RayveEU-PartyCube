<?php

declare(strict_types=1);

namespace rayveeu\partycube\form;

use pocketmine\player\Player;
use rayveeu\essentials\form\inventory\InventoryForm;
use rayveeu\essentials\player\Session;
use rayveeu\essentials\util\ItemUtils;
use rayveeu\partycube\minigame\MinigameManager;

class ForceMinigameForm{
    public static function open(Player $player): void {
        $session = Session::getNullSafe($player);

        $form = new InventoryForm(27, $session->translate("ui.title.force_minigame"));
        self::sendMinigames($player, $form);
        $form->sendToPlayer($player);
    }

    private static function sendMinigames(Player $player, InventoryForm $form): void {
        $session = Session::getNullSafe($player);

        $form->clearAll();
        foreach(MinigameManager::getAll() as $minigame) {
            $item = $minigame->getItem()->setCustomName("§r".$session->translate($minigame->getName()));
            if($minigame->isForced()) {
                $item = ItemUtils::addFakeEnchantment($item);
            }
            $form->addButton($item, function(Player $player) use ($minigame, $form): void {
                foreach(MinigameManager::getAll() as $minigames) {
                    $minigames->setForced(false);
                }
                $minigame->setForced(true);
                self::sendMinigames($player, $form);
                Session::getNullSafe($player)->playSound("random.levelup", 1.0, 0.6);
            });
        }
    }
}