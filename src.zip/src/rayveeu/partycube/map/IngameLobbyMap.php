<?php

declare(strict_types=1);

namespace rayveeu\partycube\map;

use Closure;
use minigame\map\StoredMap;
use pocketmine\event\player\PlayerMoveEvent;
use pocketmine\Server;
use rayveeu\essentials\util\SpawnPosition;

class IngameLobbyMap extends StoredMap{
    public const NAME = "PartyCube-Ingame-Lobby-1";

    public function getLevelName(): string{
        return self::NAME;
    }

    public function getSpawn(): SpawnPosition{
        return new SpawnPosition(0.5, 101, 0.5, 90);
    }

    public function getCredits(): array{
        return ["zueinfxch"];
    }

    public function getDisplayName(): string{
        return "PartyCube";
    }

    public function onPlayerMove(PlayerMoveEvent $event): void{
        $to = $event->getTo();
        $player = $event->getPlayer();

        if($to->getY() <= 40) {
            $spawn = $this->getSpawn();
            $player->teleport($spawn, $spawn->getYaw());
        }
    }

    public function delete(Closure $closure): void{}

    public function load(Closure $closure): void{
        Server::getInstance()->getWorldManager()->loadWorld($this->getLevelName());
        ($closure)();
    }
}