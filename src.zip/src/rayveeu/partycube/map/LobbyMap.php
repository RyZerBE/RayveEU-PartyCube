<?php

declare(strict_types=1);

namespace rayveeu\partycube\map;


use minigame\template\map\LobbyTemplateMap;

class LobbyMap extends LobbyTemplateMap{
    public function getLevelName(): string{
        return "PartyCube";
    }

    public function getDisplayName(): string{
        return "PartyCube";
    }
}