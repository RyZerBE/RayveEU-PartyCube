<?php

declare(strict_types=1);

namespace rayveeu\partycube\minigame;

use minigame\map\Map;
use minigame\map\MapManager;
use minigame\util\Countdown;
use minigame\util\HandlerListTrait;
use pocketmine\event\block\BlockBreakEvent;
use pocketmine\event\block\BlockBurnEvent;
use pocketmine\event\block\BlockFormEvent;
use pocketmine\event\block\BlockGrowEvent;
use pocketmine\event\block\BlockPlaceEvent;
use pocketmine\event\block\BlockSpreadEvent;
use pocketmine\event\block\BlockUpdateEvent;
use pocketmine\event\block\LeavesDecayEvent;
use pocketmine\event\block\StructureGrowEvent;
use pocketmine\event\entity\EntityDamageByEntityEvent;
use pocketmine\event\entity\EntityDamageEvent;
use pocketmine\event\entity\EntityItemPickupEvent;
use pocketmine\event\inventory\CraftItemEvent;
use pocketmine\event\inventory\InventoryTransactionEvent;
use pocketmine\event\player\PlayerDropItemEvent;
use pocketmine\event\player\PlayerExhaustEvent;
use pocketmine\event\player\PlayerInteractEvent;
use pocketmine\event\player\PlayerItemConsumeEvent;
use pocketmine\event\player\PlayerRespawnEvent;
use pocketmine\item\Item;
use pocketmine\player\Player;
use rayveeu\essentials\util\SpawnPosition;
use rayveeu\partycube\PartyCube;
use rayveeu\partycube\util\ranking\LowestPointsRanking;
use rayveeu\partycube\util\ranking\Ranking;
use rayveeu\replaysystem\studio\ReplayStudio;

abstract class Minigame{
    use HandlerListTrait;

    protected bool $forced = false;

    protected Countdown $timer;
    protected Ranking $ranking;

    public Map $map;

    protected bool $initialized = false;

    protected bool $running = false;

    protected MinigameSettings $settings;

    public function onEnable(): void {}

    public function onLoad(): void {}

    public function onStart(): void {}
    public function onStop(): void {}

    public function tick(int $tick): void {}

    public function onMapInitialize(): void {}

    abstract public function getName(): string;

    /**
     * @return Map[]
     */
    abstract public function getMapPool(): array;

    abstract public function getInitialRankingType(): Ranking;

    abstract public function getItem(): Item;

    public function getInitialSettings(): MinigameSettings {
        return new MinigameSettings();
    }

    public function getSpawnFor(Player $player): SpawnPosition {
        return $this->getMap()->getSpawn();
    }

    public function getSettings(): MinigameSettings{
        if(!isset($this->settings)) {
            $this->settings = $this->getInitialSettings();
        }
        return $this->settings;
    }

    public function setRunning(bool $running = true): void{
        $this->running = $running;
    }

    public function isRunning(): bool{
        return $this->running;
    }

    public function start(): void {
        if($this->isRunning()) {
            return;
        }
        $this->ranking = $this->getInitialRankingType();
        $this->setRunning();
        $this->timer->start();
        $this->onStart();
    }

    public function startReplay(): void {
        ReplayStudio::startRecording($this->getMap()->getWorld(), $this->getItem(), $this->getMap()->getSpawn(), "PartyCube - ".$this->getName());
    }

    public function stop(): void {
        if(!$this->isRunning()) {
            return;
        }
        $this->setRunning(false);
        $this->rankInRest();
        $this->onStop();

        $this->setInitialized(false);
    }

    protected function rankInRest(): void {
        $points = -9999999999;
        if($this->ranking instanceof LowestPointsRanking) {
            $points = 9999999999;
        }
        foreach(PartyCube::getInstance()->getSessions() as $session) {
            $this->ranking->getPoints($session->getPlayer())->set($points);
        }
    }

    public function onQueuedPlayerTeleport(Player $player): void {
    }

    public function loadMap(): Map {
        if(!isset($this->map)) {
            $maps = $this->getMapPool();
            $map = $maps[array_rand($maps)];
            MapManager::register($map);

            $map->load(function(): void{
                if(!$this->isInitialized()) {
                    $this->onMapInitialize();
                }
                $this->setInitialized();
            });
            $this->map = $map;
        }
        return $this->map;
    }

    public function getMap(): Map{
        return $this->map;
    }

    public function getRanking(): Ranking{
        return $this->ranking;
    }

    public function initTimer(): void {
        $this->timer = new Countdown(60 * 5);
    }

    public function getTimer(): Countdown{
        return $this->timer;
    }

    public function canStop(): bool {
        if($this->timer->get() <= 0) {
            return true;
        }
        return count(PartyCube::getInstance()->getSessions()) <= 1;
    }

    public function isInitialized(): bool{
        return $this->initialized;
    }

    public function setInitialized(bool $initialized = true): void{
        $this->initialized = $initialized;
    }

    public function isForced(): bool{
        return $this->forced;
    }

    public function setForced(bool $forced): void{
        $this->forced = $forced;
    }

    public function getVotes(): int {
        return 0;
    }

    public function onPlayerRespawn(PlayerRespawnEvent $event): void{
        if(!$this->getSettings()->respawnAfterDeath) {
            $player = $event->getPlayer();
            $this->getSpawnFor($player)->teleport($player);
        }
    }

    public function onPlayerExhaust(PlayerExhaustEvent $event): void{
        if(!$this->getSettings()->hunger) {
            $event->cancel();
        }
    }

    public function onEntityDamage(EntityDamageEvent $event): void{
        if(!$this->getSettings()->damage) {
            $event->cancel();
        }
    }

    public function onEntityDamageByEntity(EntityDamageByEntityEvent $event): void{
        if(!$this->getSettings()->pvp) {
            $event->cancel();
        }
    }

    public function onPlayerDropItem(PlayerDropItemEvent $event): void{
        if(!$this->getSettings()->itemDrop) {
            $event->cancel();
        }
    }

    public function onEntityItemPickup(EntityItemPickupEvent $event): void{
        if(!$this->getSettings()->itemPickup) {
            $event->cancel();
        }
    }

    public function onPlayerItemConsume(PlayerItemConsumeEvent $event): void{
        if(!$this->getSettings()->itemConsume) {
            $event->cancel();
        }
    }

    public function onBlockPlace(BlockPlaceEvent $event): void{
        if(!$this->getSettings()->blockPlacement) {
            $event->cancel();
        }
    }

    public function onBlockBreak(BlockBreakEvent $event): void{
        if(!$this->getSettings()->blockDestruction) {
            $event->cancel();
        }
    }

    public function onPlayerInteract(PlayerInteractEvent $event): void{
        if(!$this->getSettings()->blockInteraction) {
            $event->cancel();
        }
    }

    public function onBlockUpdate(BlockUpdateEvent $event): void{
        if(!$this->getSettings()->blockUpdate) {
            $event->cancel();
        }
    }

    public function onBlockGrow(BlockGrowEvent $event): void{
        if(!$this->getSettings()->blockUpdate) {
            $event->cancel();
        }
    }

    public function onStructureGrow(StructureGrowEvent $event): void{
        if(!$this->getSettings()->blockUpdate) {
            $event->cancel();
        }
    }

    public function onBlockForm(BlockFormEvent $event): void{
        if(!$this->getSettings()->blockUpdate) {
            $event->cancel();
        }
    }

    public function onBlockSpread(BlockSpreadEvent $event): void{
        if(!$this->getSettings()->blockUpdate) {
            $event->cancel();
        }
    }

    public function onBlockBurn(BlockBurnEvent $event): void{
        if(!$this->getSettings()->blockUpdate) {
            $event->cancel();
        }
    }

    public function onLeavesDecay(LeavesDecayEvent $event): void{
        if(!$this->getSettings()->blockUpdate) {
            $event->cancel();
        }
    }

    public function onInventoryTransaction(InventoryTransactionEvent $event): void{
        if(!$this->getSettings()->inventoryTransactions) {
            $event->cancel();
        }
    }

    public function onCraftItem(CraftItemEvent $event): void{
        if(!$this->getSettings()->crafting) {
            $event->cancel();
        }
    }
}