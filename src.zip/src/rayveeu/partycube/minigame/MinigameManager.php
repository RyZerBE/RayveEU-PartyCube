<?php

declare(strict_types=1);

namespace rayveeu\partycube\minigame;

use lookup\game\PartyCubeLookup;
use pocketmine\event\Listener;
use pocketmine\Server;
use RuntimeException;

class MinigameManager implements Listener{
    public const MAX_MINIGAMES = 5;

    /** @var Minigame[]  */
    private static array $minigames = [];

    private static ?Minigame $current = null;

    private static array $history = [];

    public static int $played = 0;

    public static function getAll(): array{
        return self::$minigames;
    }

    public static function register(Minigame $minigame): void {
        if(!in_array($minigame->getName(), PartyCubeLookup::GAMES, true)) {
            Server::getInstance()->getLogger()->error("Could not register game ".$minigame->getName()." due missing registry.");
            return;
        }
        self::$minigames[$minigame::class] = $minigame;
        $minigame->initTimer();
        $minigame->onEnable();
    }

    public static function get(string $minigame): ?Minigame {
        return self::$minigames[$minigame] ?? null;
    }

    public static function getByName(string $name): ?Minigame {
        foreach(self::getAll() as $minigame) {
            if($minigame->getName() === $name) {
                return $minigame;
            }
        }
        return null;
    }

    public static function getRunningMinigame(): ?Minigame {
        $current = self::getCurrent();
        if($current === null) {
            return null;
        }
        if(!$current->isRunning()) {
            return null;
        }
        return $current;
    }

    public static function getCurrent(): ?Minigame{
        return self::$current;
    }

    public static function getCurrentNullSafe(): Minigame {
        $current = self::$current;
        if($current === null) {
            throw new RuntimeException("Minigame must not be null.");
        }
        return $current;
    }

    public static function setCurrent(Minigame $current): void{
        Server::getInstance()->getLogger()->info($current->getName()." will be played next");
        unset($current->map);
        $current->loadMap();
        self::$current = $current;
        $current->getTimer()->reset();
        $current->onLoad();
    }

    public static function initNext(): void {
        if(self::getCurrent() !== null) {
            self::$history[] = self::$current->getName();
            if(count(self::$history) >= count(self::getAll())) {
                self::$history = [];
            }
        }
        $list = [];
        $minigames = self::getAll();
        shuffle($minigames);
        foreach($minigames as $minigame) {
            if(!$minigame->isForced() && in_array($minigame->getName(), self::$history, true)) {
                continue;
            }
            $list[$minigame::class] = ($minigame->isForced() ? PHP_INT_MAX : $minigame->getVotes());

            $minigame->setForced(false);
        }
        arsort($list);
        $keys = array_keys($list);
        $minigame = self::get(array_shift($keys) ?? "");
        if(!$minigame instanceof Minigame) {
            throw new RuntimeException("Minigame must be instance of Minigame class.");
        }
        self::setCurrent($minigame);
    }
}