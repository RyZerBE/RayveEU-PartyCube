<?php

declare(strict_types=1);

namespace rayveeu\partycube\minigame;

class MinigameSettings{
    public bool $hunger = false;
    public bool $damage = false;
    public bool $respawnAfterDeath = false;
    public bool $pvp = false;

    public bool $itemDrop = false;
    public bool $itemPickup = false;
    public bool $itemConsume = false;

    public bool $blockPlacement = false;
    public bool $blockDestruction = false;
    public bool $blockInteraction = false;
    public bool $blockUpdate = false;

    public bool $inventoryTransactions = false;
    public bool $crafting = false;
}