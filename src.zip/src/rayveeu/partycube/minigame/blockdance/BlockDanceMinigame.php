<?php

declare(strict_types=1);

namespace rayveeu\partycube\minigame\blockdance;

use minigame\map\Map;
use pocketmine\block\VanillaBlocks;
use pocketmine\item\Item;
use rayveeu\partycube\minigame\blockdance\map\StoneCircleBlockDanceMap;
use rayveeu\partycube\minigame\Minigame;
use rayveeu\partycube\util\ranking\HighestPointsRanking;
use rayveeu\partycube\util\ranking\Ranking;

class BlockDanceMinigame extends Minigame{
    public function getName(): string{
        return "Block Dance";
    }

    public function getMapPool(): array{
        return [
            new StoneCircleBlockDanceMap(),
        ];
    }

    public function getInitialRankingType(): Ranking{
        return new HighestPointsRanking();
    }

    public function getItem(): Item{
        return VanillaBlocks::TALL_GRASS()->asItem();
    }


}