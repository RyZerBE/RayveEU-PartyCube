<?php

declare(strict_types=1);

namespace rayveeu\partycube\minigame\blockdance\map;

use minigame\map\StoredMap;
use pocketmine\math\AxisAlignedBB;
use rayveeu\essentials\util\SpawnPosition;

abstract class BlockDanceMap extends StoredMap{
    abstract public function getDeathHeight(): int;

    abstract public function getDanceArea(): AxisAlignedBB;
}