<?php

declare(strict_types=1);

namespace rayveeu\partycube\minigame\blockdance\map;

use pocketmine\math\AxisAlignedBB;
use rayveeu\essentials\util\math\Math;
use rayveeu\essentials\util\SpawnPosition;

class StoneCircleBlockDanceMap extends BlockDanceMap{
    public function getDeathHeight(): int{
        return 14;
    }

    public function getDanceArea(): AxisAlignedBB{
        return Math::makeAxisAlignedBB(-26, 16, 26, 26, 16, -26);
    }

    public function getLevelName(): string{
        return "BlockDance-1";
    }

    public function getSpawn(): SpawnPosition{
        return new SpawnPosition(0.5, 17.1, 0.5, 0);
    }

    public function getCredits(): array{
        return ["zueinfxch"];
    }

    public function getDisplayName(): string{
        return "Stone Circle";
    }
}