<?php

declare(strict_types=1);

namespace rayveeu\partycube\minigame\escapethehylope;

use minigame\player\MinigamePlayerType;
use pocketmine\block\VanillaBlocks;
use pocketmine\entity\Location;
use pocketmine\event\entity\EntityDamageEvent;
use pocketmine\event\player\PlayerMoveEvent;
use pocketmine\event\player\PlayerRespawnEvent;
use pocketmine\item\Item;
use pocketmine\item\VanillaItems;
use pocketmine\math\Vector3;
use pocketmine\network\mcpe\protocol\types\BossBarColor;
use pocketmine\player\Player;
use pocketmine\Server;
use rayveeu\essentials\player\Session;
use rayveeu\essentials\util\BuilderUtils;
use rayveeu\essentials\world\generator\VoidGenerator;
use rayveeu\partycube\minigame\escapethehylope\generator\ClassicEscapeTheHylopeGenerator;
use rayveeu\partycube\minigame\escapethehylope\generator\DesertEscapeTheHylopeGenerator;
use rayveeu\partycube\minigame\escapethehylope\map\EscapeTheHylopeMap;
use rayveeu\partycube\minigame\Minigame;
use rayveeu\partycube\PartyCube;
use rayveeu\partycube\util\ranking\HighestPointsRanking;
use rayveeu\partycube\util\ranking\Ranking;

class EscapeTheHylope extends Minigame{
    public const PARKOUR_LENGTH = 300;

    private array $updateBossbar = [];
    private EscapeTheHylopeEntity $entity;

    public array $yLine = [];

    public function getName(): string{
        return "Escape the Hylope";
    }

    public function getMapPool(): array{
        return [
            new EscapeTheHylopeMap("ETH", VoidGenerator::class),
        ];
    }

    public function getItem(): Item{
        return VanillaItems::IRON_BOOTS();
    }

    public function getGenerator(): array {
        return [
            new ClassicEscapeTheHylopeGenerator($this->getMap()->getLevelName()),
            new DesertEscapeTheHylopeGenerator($this->getMap()->getLevelName()),
        ];
    }

    public function getInitialRankingType(): Ranking{
        return new HighestPointsRanking();
    }

    protected function rankInRest(): void {
        $goal = new Vector3(300, 0, 0);
        foreach(PartyCube::getInstance()->getSessions() as $session) {
            $this->ranking->getPoints($session->getPlayer())->set((int)floor($this->getReachedPercentage($session->getPlayer(), $goal) * 100));
        }
    }

    public function onStart(): void{
        $this->updateBossbar = [];
        BuilderUtils::fill($this->getMap()->getWorld(), new Vector3(4, 100, -4), new Vector3(4, 104, 8), VanillaBlocks::AIR());
        foreach(PartyCube::getInstance()->getSessions() as $session) {
            $bossbar = $session->getBossbar();
            $bossbar->setColor(BossBarColor::GREEN);
            $bossbar->setPercentage(0.0);
            $bossbar->show();
        }
        $this->entity->sendSkin();
    }

    public function tick(int $tick): void{
        $goal = new Vector3(300, 0, 0);
        while($xboxId = array_shift($this->updateBossbar)) {
            $session = Session::get($xboxId);
            if($session === null) {
                continue;
            }
            $session->getBossbar()->setPercentage($this->getReachedPercentage($session->getPlayer(), $goal));
        }
    }

    public function onMapInitialize(): void{
        $generator = $this->getGenerator();
        Server::getInstance()->getAsyncPool()->submitTask($generator[array_rand($generator)]);

        $spawn = $this->map->getSpawn();
        $this->entity = new EscapeTheHylopeEntity(Location::fromObject($spawn->subtract(25, 6, 0), $this->map->getWorld(), $spawn->getYaw()));
        $this->entity->spawnToAll();
    }

    private function getReachedPercentage(Player $player, Vector3 $goal): float {
        $position = $player->getPosition();
        $position->y = 0;
        $distance = $position->distance($goal);

        $percentage = $distance / self::PARKOUR_LENGTH;
        return 1.005 - $percentage;
    }

    public function onPlayerMove(PlayerMoveEvent $event): void{
        $player = $event->getPlayer();
        if(MinigamePlayerType::get($player)->isSpectator()) {
            return;
        }
        $xboxId = $player->getXuid();
        $this->updateBossbar[$xboxId] = $xboxId;

        $to = $event->getTo();
        if($to->getY() <= 50 || $to->getX() <= $this->entity->getLocation()->getX()) {
            $player->attack(new EntityDamageEvent($player, EntityDamageEvent::CAUSE_VOID, 9999));
            return;
        }

        if($player->isOnGround() && $to->getX() >= self::PARKOUR_LENGTH) {
            $session = Session::getNullSafe($player);

            $session->reset();
            $session->getBossbar()->hide();

            $this->getRanking()->fixPlacement($player);

            PartyCube::getInstance()->broadcastMessage("message.player_finished", [
                "player" => $session->getDisplayName()
            ]);

            MinigamePlayerType::get($event->getPlayer())->setSpectator(true);
        }
    }

    public function onEntityDamage(EntityDamageEvent $event): void{
        if(in_array($event->getCause(), [EntityDamageEvent::CAUSE_VOID, EntityDamageEvent::CAUSE_CUSTOM], true)) {
            $event->uncancel();
            return;
        }
        $event->cancel();
    }

    public function onPlayerRespawn(PlayerRespawnEvent $event): void{ $player = $event->getPlayer();
        $session = Session::getNullSafe($player);

        $session->reset();

        PartyCube::getInstance()->broadcastMessage("message.player_died", [
            "player" => $session->getDisplayName()
        ]);

        $this->getRanking()->getPoints($player)->set((int)floor($this->getReachedPercentage($session->getPlayer(), new Vector3(300, 0, 0)) * 100));

        MinigamePlayerType::get($event->getPlayer())->setSpectator(true);

        $event->setRespawnPosition(Location::fromObject($this->entity->getLocation(), $this->getMap()->getWorld(), 0, 0));
    }
}