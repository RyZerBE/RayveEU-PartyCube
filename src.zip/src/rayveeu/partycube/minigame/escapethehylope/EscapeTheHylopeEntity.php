<?php

declare(strict_types=1);

namespace rayveeu\partycube\minigame\escapethehylope;

use minigame\player\MinigamePlayerType;
use pocketmine\block\VanillaBlocks;
use pocketmine\data\bedrock\block\BlockTypeNames;
use pocketmine\entity\EntitySizeInfo;
use pocketmine\entity\Human;
use pocketmine\entity\Location;
use pocketmine\event\entity\EntityDamageEvent;
use pocketmine\math\Vector3;
use pocketmine\network\mcpe\convert\BlockStateDictionary;
use pocketmine\network\mcpe\protocol\types\entity\EntityIds;
use pocketmine\player\Player;
use pocketmine\world\ChunkLoader;
use pocketmine\world\particle\BlockBreakParticle;
use rayveeu\essentials\util\CommonSkins;
use rayveeu\partycube\minigame\MinigameManager;

class EscapeTheHylopeEntity extends Human implements ChunkLoader{
    protected int $targetY = 100;

    public function __construct(Location $location){
        parent::__construct($location, CommonSkins::HYLOPE(), null);
        $this->setScale(6);

        $this->gravityEnabled = false;

        $this->getWorld()->registerChunkLoader($this, $location->getFloorX() >> 4, $location->getFloorZ() >> 4, true);
    }

    protected function onFirstUpdate(int $currentTick): void{
        parent::onFirstUpdate($currentTick);
        $this->sendSkin();
    }

    protected function getInitialSizeInfo(): EntitySizeInfo{
        return new EntitySizeInfo(2.9, 0.9);
    }

    public static function getNetworkTypeId(): string{
        return EntityIds::WARDEN;
    }

    public function getName(): string{
        return "Hylope";
    }

    public function onUpdate(int $currentTick): bool{
        $minigame = MinigameManager::getCurrent();
        if(!$minigame instanceof EscapeTheHylope) {
            $this->flagForDespawn();
            return false;
        }
        if(!$minigame->isRunning()) {
            return true;
        }

        $world = $this->getWorld();
        foreach($world->getCollisionBlocks($this->getBoundingBox()->expandedCopy(1, 1, 3)) as $block) {
            $position = $block->getPosition();
            $world->setBlock($position, VanillaBlocks::AIR());
            if($block->getName() !== BlockTypeNames::INVISIBLE_BEDROCK) {
                $world->addParticle($position, new BlockBreakParticle($block));
            }
        }

        foreach($world->getCollidingEntities($this->getBoundingBox()) as $entity) {
            if(!$entity instanceof Player) {
                continue;
            }
            if(MinigamePlayerType::get($entity)->isSpectator()) {
                continue;
            }
            $entity->attack(new EntityDamageEvent($entity, EntityDamageEvent::CAUSE_VOID, 9999));
        }

        $x = $this->location->getFloorX();
        if($x >= (EscapeTheHylope::PARKOUR_LENGTH - 4)) {
            return false;
        }
        if(isset($minigame->yLine[$x])) {
            $this->targetY = $minigame->yLine[$x];
        }

        $target = $this->location->getSide($this->getHorizontalFacing())->withComponents(null, $this->targetY, null);

        $horizontal = sqrt(($target->x - $this->location->x) ** 2 + ($target->z - $this->location->z) ** 2);
        $vertical = $target->y - ($this->location->y + $this->getEyeHeight());
        $pitch = -atan2($vertical, $horizontal) / M_PI * 180;

        $y = -sin(deg2rad($pitch));
        $xz = cos(deg2rad($pitch));
        $x = -$xz * sin(deg2rad($this->location->yaw));
        $z = $xz * cos(deg2rad($this->location->yaw));

        $directionVector = (new Vector3($x, $y, $z))->normalize();

        $this->motion = $directionVector->multiply(0.31);
        return parent::onUpdate($currentTick);
    }

    public function getGravity(): float{
        return 0.0;
    }

    public function getDrag(): float{
        return 0.0;
    }

    public function canSaveWithChunk(): bool{
        return false;
    }
}