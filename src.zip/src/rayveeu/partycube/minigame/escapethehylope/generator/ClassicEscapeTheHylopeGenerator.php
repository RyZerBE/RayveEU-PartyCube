<?php

declare(strict_types=1);

namespace rayveeu\partycube\minigame\escapethehylope\generator;

class ClassicEscapeTheHylopeGenerator extends EscapeTheHylopeGenerator{
}