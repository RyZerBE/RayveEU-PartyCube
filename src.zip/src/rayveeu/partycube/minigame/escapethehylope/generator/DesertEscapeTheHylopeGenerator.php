<?php

declare(strict_types=1);

namespace rayveeu\partycube\minigame\escapethehylope\generator;

use pocketmine\block\Block;
use pocketmine\block\VanillaBlocks;
use pocketmine\math\AxisAlignedBB;
use pocketmine\math\Facing;
use pocketmine\math\Vector3;
use rayveeu\partycube\minigame\escapethehylope\EscapeTheHylope;

class DesertEscapeTheHylopeGenerator extends EscapeTheHylopeGenerator{
    protected function generateSpawn(int &$x, int &$y, int &$z, array &$chunks): void {
        $this->fill(new Vector3(-1, 100, -1), new Vector3(4, 108, 6), [VanillaBlocks::INVISIBLE_BEDROCK()], $chunks);
        $this->fill(new Vector3(0, 101, 0), new Vector3(3, 105, 5), [VanillaBlocks::AIR()], $chunks);
        $this->fill(new Vector3($x, $y, $z), new Vector3($x + 3, $y - 1, ($z + 5)), [VanillaBlocks::SMOOTH_SANDSTONE(), VanillaBlocks::SANDSTONE()], $chunks);
    }

    protected function generateCube(int $x, int $y, int $z, int $size, array &$chunks): void{
        $bb = $this->placeCube($x, $y, $z, $size, $chunks, VanillaBlocks::SANDSTONE(), [VanillaBlocks::SAND(), VanillaBlocks::SAND(), VanillaBlocks::SAND(), VanillaBlocks::SMOOTH_SANDSTONE(), VanillaBlocks::SANDSTONE()]);

        $decorations = [VanillaBlocks::CACTUS(), VanillaBlocks::DEAD_BUSH()];
        for($i = 0; $i <= 10; $i++) {
            if(random_int(0, 100) <= 15) {
                $dX = random_int((int)$bb->minX, (int)$bb->maxX);
                if($dX >= EscapeTheHylope::PARKOUR_LENGTH) {
                    $dX = EscapeTheHylope::PARKOUR_LENGTH - 1;
                }

                $dZ = random_int((int)$bb->minZ, (int)$bb->maxZ);
                $dY = (int)$bb->maxY;

                if(!$this->getBlock($dX, $dY, $dZ, $chunks)->isSameState(VanillaBlocks::SAND()) || !$this->getBlock($dX, ++$dY, $dZ, $chunks)->isSameState(VanillaBlocks::AIR())) {
                    continue;
                }

                $vector3 = new Vector3($dX, $dY, $dZ);
                foreach(Facing::HORIZONTAL as $side) {
                    $side = $vector3->getSide($side);
                    foreach($decorations as $decoration) {
                        if($this->getBlock($side->getFloorX(), $side->getFloorY(), $side->getFloorZ(), $chunks)->isSameState($decoration)) {
                            continue 3;
                        }
                    }
                }
                $block = $decorations[array_rand($decorations)];
                if($block->isSameState(VanillaBlocks::CACTUS())) {
                    for($height = 0; $height <= 2; $height++) {
                        $this->setBlock($dX, $dY + $height, $dZ, $block, $chunks);
                    }
                    continue;
                }
                $this->setBlock($dX, $dY, $dZ, $block, $chunks);
            }
        }
    }

    protected function placeCube(int $x, int $y, int $z, int $size, array &$chunks, Block $border, array $inside): AxisAlignedBB{
        $pos1 = new Vector3($x, $y, $z - random_int(-3, 3));
        $pos2 = new Vector3($x + $size, $y - 3, ($z + 5) - random_int(-3, 4));

        $this->fill($pos1, $pos2, $inside, $chunks);

        $minX = min($pos1->getX(), $pos2->getX());
        $minY = min($pos1->getY(), $pos2->getY());
        $minZ = min($pos1->getZ(), $pos2->getZ());

        $maxX = max($pos1->getX(), $pos2->getX());
        $maxY = max($pos1->getY(), $pos2->getY());
        $maxZ = max($pos1->getZ(), $pos2->getZ());
        return new AxisAlignedBB($minX, $minY, $minZ, $maxX, $maxY, $maxZ);
    }
}