<?php

declare(strict_types=1);

namespace rayveeu\partycube\minigame\escapethehylope\generator;

use pocketmine\block\Block;
use pocketmine\block\utils\DyeColor;
use pocketmine\block\VanillaBlocks;
use pocketmine\math\AxisAlignedBB;
use pocketmine\math\Vector3;
use pocketmine\Server;
use pocketmine\utils\Random;
use pocketmine\world\format\io\FastChunkSerializer;
use pocketmine\world\World;
use rayveeu\partycube\minigame\escapethehylope\EscapeTheHylope;
use rayveeu\partycube\minigame\MinigameManager;
use rayveeu\partycube\util\AsyncGenerator;

abstract class EscapeTheHylopeGenerator extends AsyncGenerator{
    public function __construct(
        protected string $world
    ){}

    public function onRun(): void{
        $chunks = [];

        $yLine = [];

        $random = new Random(mt_rand());

        $x = 0;
        $y = 100;
        $z = 0;

        $this->generateSpawn($x, $y, $z, $chunks);

        $x = 3;
        while($x < (EscapeTheHylope::PARKOUR_LENGTH - 2)) {
            $this->generateJump($random, $x, $y);

            $size = $random->nextRange(2, 5);
            $this->generateCube($x, $y, $z, $size, $chunks);
            $x += $size;

            $yLine[$x] = $y;
        }

        $this->generateGoal($x, $y, $z, $chunks);

        $result = [];
        foreach($chunks as $hash => $chunk) {
            $result[$hash] = FastChunkSerializer::serializeTerrain($chunk);
        }

        $this->setResult([
            $result,
            $yLine
        ]);
    }

    public function onCompletion(): void{
        $world = Server::getInstance()->getWorldManager()->getWorldByName($this->world);
        if($world === null) {
            return;
        }
        $result = $this->getResult();

        foreach($result[0] as $hash => $chunk) {
            World::getXZ($hash, $chunkX, $chunkZ);
            $world->setChunk($chunkX, $chunkZ, FastChunkSerializer::deserializeTerrain($chunk));
        }

        MinigameManager::getCurrentNullSafe()->yLine = $result[1];
    }

    protected function generateSpawn(int &$x, int &$y, int &$z, array &$chunks): void {
        $this->fill(new Vector3(-1, 100, -1), new Vector3(4, 108, 6), [VanillaBlocks::INVISIBLE_BEDROCK()], $chunks);
        $this->fill(new Vector3(0, 101, 0), new Vector3(3, 105, 5), [VanillaBlocks::AIR()], $chunks);
        $this->fill(new Vector3($x, $y, $z), new Vector3($x + 3, $y - 1, ($z + 5)), [VanillaBlocks::SMOOTH_STONE()], $chunks);
    }

    protected function generateGoal(int &$x, int &$y, int &$z, array &$chunks): void {
        $this->fill(new Vector3(300, $y - 2, -10), new Vector3(310, $y, 10), [VanillaBlocks::CONCRETE()->setColor(DyeColor::WHITE())], $chunks);
        $this->fill(new Vector3(300, $y - 3, -10), new Vector3(310, $y - 3, 10), [VanillaBlocks::SMOOTH_STONE()], $chunks);
    }

    protected function generateCube(int $x, int $y, int $z, int $size, array &$chunks): void {
        $colors = DyeColor::getAll();
        $color = $colors[array_rand($colors)];
        $this->placeCube($x, $y, $z, $size, $chunks, VanillaBlocks::CONCRETE()->setColor($color), [VanillaBlocks::STAINED_GLASS()->setColor($color)]);
    }

    protected function generateJump(Random $random, int &$x, int &$y): void {
        $xDistance = $random->nextRange(2, 4);
        if($xDistance <= 3 && $random->nextRange(0, 100) <= 50) {
            $y += min(1, $random->nextRange(-2, 5));
        } elseif($xDistance <= 4 && $random->nextRange(0, 100) <= 50) {
            $y += $random->nextRange(-3, -1);
        }
        if($y < 90) {
            $y = 90;
        }
        $x += $xDistance;
    }

    protected function placeCube(int $x, int $y, int $z, int $size, array &$chunks, Block $border, array $inside): AxisAlignedBB {
        $pos1 = new Vector3($x, $y, $z - random_int(-3, 3));
        $pos2 = new Vector3($x + $size, $y - 3, ($z + 5) - random_int(-3, 4));

        $this->fill($pos1, $pos2, $inside, $chunks);

        $minX = min($pos1->getX(), $pos2->getX());
        $minY = min($pos1->getY(), $pos2->getY());
        $minZ = min($pos1->getZ(), $pos2->getZ());

        $maxX = max($pos1->getX(), $pos2->getX());
        $maxY = max($pos1->getY(), $pos2->getY());
        $maxZ = max($pos1->getZ(), $pos2->getZ());

        for($xSide = $minX; $xSide <= $maxX; $xSide++) {
            $this->setBlock($xSide, $minY, $minZ, $border, $chunks);
            $this->setBlock($xSide, $minY, $maxZ, $border, $chunks);

            $this->setBlock($xSide, $maxY, $minZ, $border, $chunks);
            $this->setBlock($xSide, $maxY, $maxZ, $border, $chunks);
        }

        for($zSide = $minZ; $zSide <= $maxZ; $zSide++) {
            $this->setBlock($minX, $minY, $zSide, $border, $chunks);
            $this->setBlock($maxX, $minY, $zSide, $border, $chunks);

            $this->setBlock($minX, $maxY, $zSide, $border, $chunks);
            $this->setBlock($maxX, $maxY, $zSide, $border, $chunks);
        }

        for($ySide = $minY; $ySide <= $maxY; $ySide++) {
            $this->setBlock($minX, $ySide, $minZ, $border, $chunks);
            $this->setBlock($maxX, $ySide, $minZ, $border, $chunks);
            $this->setBlock($minX, $ySide, $maxZ, $border, $chunks);
            $this->setBlock($maxX, $ySide, $maxZ, $border, $chunks);
        }
        return new AxisAlignedBB($minX, $minY, $minZ, $maxX, $maxY, $maxZ);
    }
}