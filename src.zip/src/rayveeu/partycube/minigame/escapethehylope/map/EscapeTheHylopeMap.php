<?php

declare(strict_types=1);

namespace rayveeu\partycube\minigame\escapethehylope\map;

use minigame\map\GeneratedMap;
use rayveeu\essentials\util\SpawnPosition;

class EscapeTheHylopeMap extends GeneratedMap{
    public function getSpawn(): SpawnPosition{
        return new SpawnPosition(2.5, 101.5, 3, 270);
    }

    public function getDisplayName(): string{
        return "Escape The Hylope";
    }
}