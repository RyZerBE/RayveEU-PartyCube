<?php

declare(strict_types=1);

namespace rayveeu\partycube\minigame\escapethelava;

use minigame\map\MapManager;
use minigame\player\MinigamePlayerType;
use minigame\util\BlockCache;
use minigame\util\Countdown;
use pocketmine\block\Block;
use pocketmine\block\Sapling;
use pocketmine\block\utils\WoodType;
use pocketmine\block\VanillaBlocks;
use pocketmine\data\bedrock\BiomeIds;
use pocketmine\entity\effect\Effect;
use pocketmine\entity\effect\EffectInstance;
use pocketmine\entity\effect\VanillaEffects;
use pocketmine\event\block\BlockBreakEvent;
use pocketmine\event\block\BlockPlaceEvent;
use pocketmine\event\block\StructureGrowEvent;
use pocketmine\event\entity\EntityDamageByEntityEvent;
use pocketmine\event\player\PlayerMoveEvent;
use pocketmine\event\player\PlayerRespawnEvent;
use pocketmine\event\world\ChunkLoadEvent;
use pocketmine\inventory\SimpleInventory;
use pocketmine\item\Item;
use pocketmine\item\PotionType;
use pocketmine\item\Tool;
use pocketmine\item\VanillaItems;
use pocketmine\math\Vector3;
use pocketmine\player\GameMode;
use pocketmine\player\Player;
use pocketmine\Server;
use pocketmine\utils\Random;
use pocketmine\world\biome\BiomeRegistry;
use pocketmine\world\format\Chunk;
use pocketmine\world\generator\GeneratorManager;
use pocketmine\world\generator\object\TreeFactory;
use pocketmine\world\particle\BlockBreakParticle;
use pocketmine\world\particle\HappyVillagerParticle;
use pocketmine\world\World;
use rayveeu\essentials\music\GenericSounds;
use rayveeu\essentials\player\Session;
use rayveeu\essentials\util\BuilderUtils;
use rayveeu\essentials\util\TitleFormat;
use rayveeu\partycube\minigame\escapethelava\generator\biome\ExtremeHills;
use rayveeu\partycube\minigame\escapethelava\generator\EscapeTheLavaGenerator;
use rayveeu\partycube\minigame\escapethelava\map\EscapeTheLavaMap;
use rayveeu\partycube\minigame\escapethelava\reward\BreakReward;
use rayveeu\partycube\minigame\escapethelava\util\EscapeTheLavaChunk;
use rayveeu\partycube\minigame\Minigame;
use rayveeu\partycube\minigame\MinigameSettings;
use rayveeu\partycube\PartyCube;
use rayveeu\partycube\util\ranking\LowestPointsRanking;
use rayveeu\partycube\util\ranking\Ranking;
use rayveeu\replaysystem\studio\ReplayStudio;
use ReflectionClass;

class EscapeTheLava extends Minigame{
    public const BUILD_HEIGHT = 150;

    public int $buildHeight = self::BUILD_HEIGHT;

    /** @var EscapeTheLavaChunk[]  */
    private array $chunks = [];
    /** @var EscapeTheLavaChunk[]  */
    private array $chunkQueue = [];

    private int $lavaHeight = 0;

    /** @var BreakReward[][]  */
    private array $blockRewards = [];

    /** @var Block[]  */
    private array $blockQueue = [];
    /** @var bool[]  */
    private array $blockHashes = [];

    public function getName(): string{
        return "Escape the Lava";
    }

    public function getMapPool(): array{
        return [
            new EscapeTheLavaMap("EscapeTheLava", EscapeTheLavaGenerator::class),
        ];
    }

    public function getInitialSettings(): MinigameSettings{
        return new EscapeTheLavaSettings();
    }

    public function getInitialRankingType(): Ranking{
        return new LowestPointsRanking();
    }

    public function getItem(): Item{
        return VanillaBlocks::LAVA()->asItem();
    }

    public function initTimer(): void{
        $this->timer = new Countdown(60 * 20);//20 Minutes
    }

    public function onEnable(): void{
        GeneratorManager::getInstance()->addGenerator(EscapeTheLavaGenerator::class, "etl", fn() => null, true);

        /** @var BiomeRegistry $biome */
        $biome = BiomeRegistry::getInstance();
        $biome->register(BiomeIds::EXTREME_HILLS, new ExtremeHills());

        //Dirt
        $this->addReward(new BreakReward(VanillaBlocks::DIRT(), 3, function(Player $player): void {
            $player->getInventory()->addItem(VanillaItems::GOLDEN_SHOVEL());
        }, function(Player $player): bool {
            return !$player->getInventory()->contains(VanillaItems::GOLDEN_SHOVEL());
        }));

        //Grass
        $this->addReward(new BreakReward(VanillaBlocks::GRASS(), 5, function(Player $player): void {
            $player->getInventory()->addItem(VanillaItems::GOLDEN_SHOVEL());
        }, function(Player $player): bool {
            return !$player->getInventory()->contains(VanillaItems::GOLDEN_SHOVEL());
        }));

        //Oak Log
        $this->addReward(new BreakReward(VanillaBlocks::OAK_LOG(), 5, function(Player $player): void {
            $player->getInventory()->addItem(VanillaItems::GOLDEN_AXE());
        }, function(Player $player): bool {
            return !$player->getInventory()->contains(VanillaItems::GOLDEN_AXE());
        }));

        //Spruce Log
        $this->addReward(new BreakReward(VanillaBlocks::SPRUCE_LOG(), 5, function(Player $player): void {
            $player->getInventory()->addItem(VanillaItems::GOLDEN_AXE());
        }, function(Player $player): bool {
            return !$player->getInventory()->contains(VanillaItems::GOLDEN_AXE());
        }));

        //Oak Leaves
        $this->addReward(new BreakReward(VanillaBlocks::OAK_LEAVES(), 80, function(Player $player): void {
            $player->getInventory()->addItem(VanillaItems::GOLDEN_HOE());
        }, function(Player $player): bool {
            return !$player->getInventory()->contains(VanillaItems::GOLDEN_HOE());
        }));

        //Spruce Leaves
        $this->addReward(new BreakReward(VanillaBlocks::SPRUCE_LEAVES(), 80, function(Player $player): void {
            $player->getInventory()->addItem(VanillaItems::GOLDEN_HOE());
        }, function(Player $player): bool {
            return !$player->getInventory()->contains(VanillaItems::GOLDEN_HOE());
        }));

        //Stone
        $this->addReward(new BreakReward(VanillaBlocks::STONE(), 100, function(Player $player): void {
            $player->getInventory()->addItem(VanillaItems::GOLDEN_PICKAXE());
        }, function(Player $player): bool {
            return !$player->getInventory()->getItemInHand() instanceof Tool;
        }));
        $this->addReward(new BreakReward(VanillaBlocks::STONE(), 20, function(Player $player): void {
            $player->getEffects()->add(new EffectInstance(VanillaEffects::NIGHT_VISION(), 20 * 10, 1, false));
        }, function(Player $player): bool {
            return $player->getInventory()->getItemInHand() instanceof Tool;
        }));

        //Iron ore
        $this->addReward(new BreakReward(VanillaBlocks::IRON_ORE(), 25, function(Player $player): array {
            $player->getInventory()->addItem(VanillaItems::IRON_BOOTS());
            return [];
        }, function(Player $player): bool {
            return !$player->getInventory()->contains(VanillaItems::IRON_BOOTS());
        }));
        $this->addReward(new BreakReward(VanillaBlocks::IRON_ORE(), 25, function(Player $player): array {
            $player->getInventory()->addItem(VanillaItems::IRON_LEGGINGS());
            return [];
        }, function(Player $player): bool {
            return !$player->getInventory()->contains(VanillaItems::IRON_LEGGINGS());
        }));
        $this->addReward(new BreakReward(VanillaBlocks::IRON_ORE(), 25, function(Player $player): array {
            $player->getInventory()->addItem(VanillaItems::IRON_CHESTPLATE());
            return [];
        }, function(Player $player): bool {
            return !$player->getInventory()->contains(VanillaItems::IRON_CHESTPLATE());
        }));
        $this->addReward(new BreakReward(VanillaBlocks::IRON_ORE(), 25, function(Player $player): array {
            $player->getInventory()->addItem(VanillaItems::IRON_HELMET());
            return [];
        }, function(Player $player): bool {
            return !$player->getInventory()->contains(VanillaItems::IRON_HELMET());
        }));
        $this->addReward(new BreakReward(VanillaBlocks::IRON_ORE(), 25, function(Player $player): array {
            $player->getInventory()->addItem(VanillaItems::IRON_PICKAXE());
            return [];
        }, function(Player $player): bool {
            return !$player->getInventory()->contains(VanillaItems::IRON_PICKAXE());
        }));

        //Coal ore
        $this->addReward(new BreakReward(VanillaBlocks::COAL_ORE(), 2, function(Player $player): void {
            $player->getInventory()->addItem(VanillaItems::POTION()->setType(PotionType::STRONG_LEAPING()));
        }));
        $this->addReward(new BreakReward(VanillaBlocks::COAL_ORE(), 2, function(Player $player): void {
            $player->getInventory()->addItem(VanillaItems::POTION()->setType(PotionType::HEALING()));
        }));
        $this->addReward(new BreakReward(VanillaBlocks::COAL_ORE(), 10, function(Player $player): array {
            $player->getInventory()->addItem(VanillaItems::GOLDEN_HELMET());
            return [];
        }, function(Player $player): bool {
            return !$player->getInventory()->contains(VanillaItems::GOLDEN_HELMET());
        }));
        $this->addReward(new BreakReward(VanillaBlocks::COAL_ORE(), 10, function(Player $player): array {
            $player->getInventory()->addItem(VanillaItems::GOLDEN_CHESTPLATE());
            return [];
        }, function(Player $player): bool {
            return !$player->getInventory()->contains(VanillaItems::GOLDEN_CHESTPLATE());
        }));
        $this->addReward(new BreakReward(VanillaBlocks::COAL_ORE(), 10, function(Player $player): array {
            $player->getInventory()->addItem(VanillaItems::GOLDEN_LEGGINGS());
            return [];
        }, function(Player $player): bool {
            return !$player->getInventory()->contains(VanillaItems::GOLDEN_LEGGINGS());
        }));
        $this->addReward(new BreakReward(VanillaBlocks::COAL_ORE(), 10, function(Player $player): array {
            $player->getInventory()->addItem(VanillaItems::GOLDEN_BOOTS());
            return [];
        }, function(Player $player): bool {
            return !$player->getInventory()->contains(VanillaItems::GOLDEN_BOOTS());
        }));
        $this->addReward(new BreakReward(VanillaBlocks::COAL_ORE(), 20, function(Player $player): array {
            $player->getInventory()->addItem(VanillaItems::GOLDEN_PICKAXE());
            return [];
        }, function(Player $player): bool {
            return !$player->getInventory()->contains(VanillaItems::GOLDEN_PICKAXE());
        }));

        //Gold ore
        $this->addReward(new BreakReward(VanillaBlocks::GOLD_ORE(), 50, function(Player $player): array {
            $player->getInventory()->addItem(VanillaItems::IRON_HELMET());
            return [];
        }, function(Player $player): bool {
            return !$player->getInventory()->contains(VanillaItems::IRON_HELMET());
        }));
        $this->addReward(new BreakReward(VanillaBlocks::GOLD_ORE(), 50, function(Player $player): array {
            $player->getInventory()->addItem(VanillaItems::IRON_CHESTPLATE());
            return [];
        }, function(Player $player): bool {
            return !$player->getInventory()->contains(VanillaItems::IRON_CHESTPLATE());
        }));
        $this->addReward(new BreakReward(VanillaBlocks::GOLD_ORE(), 50, function(Player $player): array {
            $player->getInventory()->addItem(VanillaItems::IRON_LEGGINGS());
            return [];
        }, function(Player $player): bool {
            return !$player->getInventory()->contains(VanillaItems::IRON_LEGGINGS());
        }));
        $this->addReward(new BreakReward(VanillaBlocks::GOLD_ORE(), 50, function(Player $player): array {
            $player->getInventory()->addItem(VanillaItems::IRON_BOOTS());
            return [];
        }, function(Player $player): bool {
            return !$player->getInventory()->contains(VanillaItems::IRON_BOOTS());
        }));

        //Redstone ore
        $this->addReward(new BreakReward(VanillaBlocks::REDSTONE_ORE(), 50, function(Player $player): void {
            $player->getEffects()->add(new EffectInstance(VanillaEffects::FIRE_RESISTANCE(), 20 * 10, 1, true));
        }));
        $this->addReward(new BreakReward(VanillaBlocks::REDSTONE_ORE(), 50, function(Player $player): array {
            $player->getInventory()->addItem(VanillaItems::TOTEM());
            return [];
        }, function(Player $player): bool {
            return !$player->getInventory()->contains(VanillaItems::TOTEM());
        }));

        //Diamond ore
        $this->addReward(new BreakReward(VanillaBlocks::DIAMOND_ORE(), 50, function(Player $player): void {
            $player->getEffects()->add(new EffectInstance(VanillaEffects::FIRE_RESISTANCE(), 20 * 15, 1, true));
        }));
        $this->addReward(new BreakReward(VanillaBlocks::DIAMOND_ORE(), 50, function(Player $player): array {
            $player->getInventory()->addItem(VanillaItems::TOTEM());
            return [];
        }, function(Player $player): bool {
            return !$player->getInventory()->contains(VanillaItems::TOTEM());
        }));
        $this->addReward(new BreakReward(VanillaBlocks::DIAMOND_ORE(), 50, function(Player $player): array {
            $player->getInventory()->addItem(VanillaItems::DIAMOND_HELMET());
            return [];
        }, function(Player $player): bool {
            return !$player->getInventory()->contains(VanillaItems::DIAMOND_HELMET());
        }));
        $this->addReward(new BreakReward(VanillaBlocks::DIAMOND_ORE(), 50, function(Player $player): array {
            $player->getInventory()->addItem(VanillaItems::DIAMOND_CHESTPLATE());
            return [];
        }, function(Player $player): bool {
            return !$player->getInventory()->contains(VanillaItems::DIAMOND_CHESTPLATE());
        }));
        $this->addReward(new BreakReward(VanillaBlocks::DIAMOND_ORE(), 50, function(Player $player): array {
            $player->getInventory()->addItem(VanillaItems::DIAMOND_LEGGINGS());
            return [];
        }, function(Player $player): bool {
            return !$player->getInventory()->contains(VanillaItems::DIAMOND_LEGGINGS());
        }));
        $this->addReward(new BreakReward(VanillaBlocks::DIAMOND_ORE(), 50, function(Player $player): array {
            $player->getInventory()->addItem(VanillaItems::DIAMOND_BOOTS());
            return [];
        }, function(Player $player): bool {
            return !$player->getInventory()->contains(VanillaItems::DIAMOND_BOOTS());
        }));
    }

    public function onQueuedPlayerTeleport(Player $player): void{
        $player->setNoClientPredictions();
    }

    public function onLoad(): void{
        $this->chunks = [];
        $this->lavaHeight = 0;
    }

    protected function rankInRest(): void{
        $count = count(PartyCube::getInstance()->getSessions());
        foreach(PartyCube::getInstance()->getSessions() as $session) {
            $player = $session->getPlayer();
            $this->ranking->getPoints($player)->set($count);
        }
    }

    public function onStart(): void{
        $gamemode = GameMode::SURVIVAL();
        foreach(PartyCube::getInstance()->getSessions() as $session) {
            $player = $session->getPlayer();
            $player->setGamemode($gamemode);
            $player->setNoClientPredictions(false);
            $session->showCoordinates();

            $player->noDamageTicks = 200;
        }

        $world = $this->map->getWorld();

        $world?->setBlockAt(0, 150, 0, VanillaBlocks::AIR());

        foreach($world?->getLoadedChunks() as $hash => $chunk) {
            World::getXZ($hash, $chunkX, $chunkZ);
            $this->addChunk($chunk, $chunkX, $chunkZ);
        }

        ReplayStudio::getRecording($world)?->registerBlockClosure(VanillaBlocks::LAVA(), fn() => null);
    }

    public function startReplay(): void{
        //TODO: Implement replays
    }

    public function onStop(): void{
        foreach(Session::getAll() as $session) {
            $session->hideCoordinates();
        }
    }

    public function tick(int $tick): void{
        if($tick % 20 === 0) {
            $ingameTime = $this->timer->getInitial() - $this->timer->get();

            if($ingameTime >= 60 && count($this->chunkQueue) <= 0) {
                PartyCube::getInstance()->broadcastTitle(TitleFormat::TOP_LEFT_1, "title.current_lava_height", [
                    "height" => $this->lavaHeight,
                ]);

                $this->lavaHeight++;
                if($this->lavaHeight === 70) {
                    PartyCube::getInstance()->broadcastMessage("message.pvp_enabled");
                }
                foreach($this->chunks as $chunk) {
                    $chunk->setLavaHeight($this->lavaHeight);
                }
                $this->chunkQueue = $this->chunks;
            }
        }

        if(count($this->chunkQueue) > 0) {
            $amount = match (true) {
                ($this->lavaHeight >= 150) => 3,
                ($this->lavaHeight >= 80) => 2,
                default => 1
            };
            for($i = 1; $i <= $amount; $i++) {
                $chunk = array_shift($this->chunkQueue);
                $chunk->generateLava();
            }
        }

        if($tick % (20 * 10) === 0) {
            $item = VanillaBlocks::COBBLED_DEEPSLATE()->asItem()->setCount(8);
            foreach(PartyCube::getInstance()->getSessions() as $session) {
                $clone = clone $item;
                $clone->setLore([
                    "§r".$session->translate("item.lore.gets_destroyed_after", [
                        "time" => 15
                    ])
                ]);
                $inventory = $session->getPlayer()->getInventory();
                $count = 0;
                foreach($inventory->getContents() as $content) {
                    if($content->equals($clone, false, false)) {
                        $count += $content->getCount();
                    }
                }
                if($count >= 64) {
                    continue;
                }
                if($count >= 56) {
                    $inventory->addItem($clone->setCount(64 - $count));
                    continue;
                }
                $inventory->addItem($clone);
            }
        }

        $world = $this->map->getWorld();
        foreach($this->blockQueue[$tick] ?? [] as $hash => $block) {
            World::getBlockXYZ($hash, $x, $y, $z);
            if(!isset($this->blockHashes[$hash])) {
                continue;
            }
            $world?->addParticle(new Vector3($x, $y, $z), new BlockBreakParticle($block));
            $world?->setBlockAt($x, $y, $z, VanillaBlocks::AIR());

            unset($this->blockHashes[$hash]);
        }
        unset($this->blockQueue[$tick]);
    }

    public function getChunkAt(int $x, int $z): ?EscapeTheLavaChunk {
        return $this->chunks[World::chunkHash($x >> 4, $z >> 4)] ?? null;
    }

    public function addChunk(Chunk $chunk, int $chunkX, int $chunkZ): void {
        $empty = true;
        foreach($chunk->getSubChunks() as $subChunk) {
            if(!$subChunk->isEmptyFast()) {
                $empty = false;
                break;
            }
        }
        if($empty) {
            return;
        }
        $this->chunks[World::chunkHash($chunkX, $chunkZ)] = new EscapeTheLavaChunk($this->map->getWorld(), $chunkX, $chunkZ);
    }

    public function addReward(BreakReward $reward): void {
        $this->blockRewards[$reward->getBlock()->getStateId()][] = $reward;
    }

    /**
     * @return BreakReward[]
     */
    public function getRewards(Block $block): array {
        return $this->blockRewards[$block->getStateId()] ?? [];
    }

    public function onPlayerRespawn(PlayerRespawnEvent $event): void{
        $player = $event->getPlayer();

        $this->ranking->getPoints($player)->set(count(PartyCube::getInstance()->getSessions()));

        PartyCube::getInstance()->broadcastMessage("message.player_died", [
            "player" => Session::getNullSafe($player)->getDisplayName(),
        ]);

        MinigamePlayerType::get($player)->setSpectator(true);

        $event->setRespawnPosition($this->map->getSpawn()->asLocation($this->map->getWorld()));
    }

    public function onChunkLoad(ChunkLoadEvent $event): void{
        $this->addChunk($event->getChunk(), $event->getChunkX(), $event->getChunkZ());
    }

    public function onBlockPlace(BlockPlaceEvent $event): void{
        $player = $event->getPlayer();
        $item = $event->getItem();

        /** @var Block $block */
        foreach($event->getTransaction()->getBlocks() as [$x, $y, $z, $block]) {
            if($y >= $this->buildHeight) {
                $event->cancel();
                GenericSounds::build_height_reached($player);
                break;
            }

            if($y <= $this->lavaHeight) {
                $this->getChunkAt($x, $z)?->addTouchedHeight($y);
            }

            if($block instanceof Sapling) {
                Session::getNullSafe($player)->scheduleClosure(5, function() use ($block): void {
                    $block->onRandomTick();
                });
                $block->setReady(true);
                $player->getWorld()->scheduleDelayedBlockUpdate($block->getPosition(), 10);
            }

            if($block->isSameState(VanillaBlocks::COBBLED_DEEPSLATE())) {
                $hash = World::blockHash($x, $y, $z);

                $this->blockQueue[Server::getInstance()->getTick() + (20 * 15)][$hash] = $block;
                $this->blockHashes[$hash] = true;
            }
        }
    }

    public function onStructureGrow(StructureGrowEvent $event): void{
        $player = $event->getPlayer();
        if($player !== null) {
            $highestY = -1;
            foreach($event->getTransaction()->getBlocks() as [$x, $y, $z, $block]) {
                if($y > $highestY) {
                    $highestY = $y;
                }
            }

            if($highestY > 220) {
                $event->cancel();

                Session::getNullSafe($player)->playSound("random.fizz");
                $particle = new HappyVillagerParticle();
                $position = $player->getPosition()->add(0, 1, 0);
                $world = $player->getWorld();
                for($i = 0; $i <= 8; $i++) {
                    $world->addParticle($position->add(random_int(0, 10) / 11, random_int(0, 10) / 11, random_int(0, 10) / 11), $particle);
                }
                return;
            }

            if($highestY > $this->buildHeight) {
                PartyCube::getInstance()->broadcastMessage("message.build_height_increased_by_player", [
                    "player" => Session::getNullSafe($player)->getDisplayName(),
                    "height" => $highestY
                ]);
                $this->buildHeight = $highestY;
            }
        }
    }

    public function onBlockBreak(BlockBreakEvent $event): void{
        $block = $event->getBlock();
        $position = $block->getPosition();
        if($position->getFloorY() <= $this->lavaHeight) {
            $this->getChunkAt($position->getFloorX(), $position->getFloorZ())?->addTouchedHeight($position->getFloorY());
        }
        $world = $position->getWorld();
        $player = $event->getPlayer();

        unset($this->blockHashes[World::blockHash($position->getFloorX(), $position->getFloorY(), $position->getFloorZ())]);

        $rewards = $this->getRewards($block);
        if(count($rewards) <= 0) {
            return;
        }
        shuffle($rewards);
        foreach($rewards as $reward) {
            if(random_int(0, 100) > $reward->getChance()) {
                continue;
            }
            $condition = $reward->getCondition();
            if($condition !== null && !($condition)($player, $block)) {
                continue;
            }
            $particle = new HappyVillagerParticle();
            for($i = 0; $i <= 8; $i++) {
                $world->addParticle($position->add(random_int(0, 10) / 11, random_int(0, 10) / 11, random_int(0, 10) / 11), $particle);
            }
            GenericSounds::escape_the_lava_reward($player);
            $drops = ($reward->getReward())($player, $block);
            if(is_array($drops)) {
                $event->setDrops($drops);
            }
            break;
        }
    }

    public function onPlayerMove(PlayerMoveEvent $event): void{
        $player = $event->getPlayer();
        if(MinigamePlayerType::get($player)->isSpectator()) {
            return;
        }
        $world = $player->getWorld();
        $position = $player->getPosition();
        if($world->getBlock($position)->isSameState(VanillaBlocks::LAVA())) {
            $totem = VanillaItems::TOTEM();
            foreach([
                $player->getInventory(),
                $player->getOffHandInventory()
                    ] as $inventory) {
                /** @var SimpleInventory $inventory */
                foreach($inventory->getContents() as $slot => $item) {
                    if($item->equals($totem, false, false)) {
                        $inventory->clear($slot);

                        $position = $position->floor();

                        BuilderUtils::fill($world, $position->add(1, 2, 1), $position->add(-1, 4, -1), VanillaBlocks::AIR());
                        BuilderUtils::fill($world, $position->add(1, 2, 1), $position->add(-1, 2, -1), VanillaBlocks::COBBLESTONE());

                        $player->teleport($position->up(3)->add(0.5, 0.1, 0.5));
                        break 2;
                    }
                }
            }
        }
    }

    public function onEntityDamageByEntity(EntityDamageByEntityEvent $event): void{
        if($this->lavaHeight < 70) {
            $event->cancel();
        }
    }
}