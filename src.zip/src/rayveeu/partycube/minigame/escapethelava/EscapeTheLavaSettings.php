<?php

declare(strict_types=1);

namespace rayveeu\partycube\minigame\escapethelava;

use rayveeu\partycube\minigame\MinigameSettings;

class EscapeTheLavaSettings extends MinigameSettings{
    public bool $damage = true;
    public bool $pvp = true;

    public bool $itemDrop = true;
    public bool $itemPickup = true;
    public bool $itemConsume = true;

    public bool $blockPlacement = true;
    public bool $blockDestruction = true;
    public bool $blockInteraction = true;
    public bool $blockUpdate = true;

    public bool $inventoryTransactions = true;
    public bool $crafting = true;
}