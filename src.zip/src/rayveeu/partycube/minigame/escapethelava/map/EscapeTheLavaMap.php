<?php

declare(strict_types=1);

namespace rayveeu\partycube\minigame\escapethelava\map;

use minigame\map\GeneratedMap;
use rayveeu\essentials\util\SpawnPosition;

class EscapeTheLavaMap extends GeneratedMap{
    public function getSpawn(): SpawnPosition{
        return new SpawnPosition(0.5, 151.1, 0.5, 0);
    }

    public function getDisplayName(): string{
        return "EscapeTheLava";
    }
}