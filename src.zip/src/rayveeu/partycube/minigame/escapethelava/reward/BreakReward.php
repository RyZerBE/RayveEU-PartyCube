<?php

declare(strict_types=1);

namespace rayveeu\partycube\minigame\escapethelava\reward;

use Closure;
use pocketmine\block\Block;

class BreakReward{
    public function __construct(
        private Block    $block,
        private int $chance,
        private Closure  $reward,
        private ?Closure $condition = null,
    ){}

    public function getBlock(): Block{
        return $this->block;
    }

    public function getChance(): int{
        return $this->chance;
    }

    public function getReward(): Closure{
        return $this->reward;
    }

    public function getCondition(): ?Closure{
        return $this->condition;
    }
}