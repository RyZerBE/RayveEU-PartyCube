<?php

declare(strict_types=1);

namespace rayveeu\partycube\minigame\escapethelava\util;

use pocketmine\block\VanillaBlocks;
use pocketmine\math\Vector2;
use pocketmine\math\Vector3;
use pocketmine\world\format\Chunk;
use pocketmine\world\World;
use rayveeu\partycube\minigame\escapethelava\generator\EscapeTheLavaGenerator;
use rayveeu\replaysystem\studio\packet\AreaFillBlockPacket;
use rayveeu\replaysystem\studio\ReplayStudio;

class EscapeTheLavaChunk{
    /** @var int[]  */
    private array $touchedHeights = [];

    private int $lavaHeight = 0;

    public function __construct(
        private World $world,
        private int $chunkX,
        private int $chunkZ,
    ){}

    public function getWorld(): World{
        return $this->world;
    }

    public function getChunkX(): int{
        return $this->chunkX;
    }

    public function getChunkZ(): int{
        return $this->chunkZ;
    }

    public function addTouchedHeight(int $y): void {
        if(!in_array($y, $this->touchedHeights, true)) {
            $this->touchedHeights[] = $y;
        }
    }

    public function setLavaHeight(int $lavaHeight): void{
        $this->lavaHeight = $lavaHeight;
    }

    public function generateLava(): void {
        $world = $this->getWorld();
        $chunk = $world->loadChunk($this->chunkX, $this->chunkZ);
        if($chunk === null) {
            return;
        }
        $baseX = $this->chunkX * Chunk::EDGE_LENGTH;
        $baseZ = $this->chunkZ * Chunk::EDGE_LENGTH;

        $heights = array_merge($this->touchedHeights, [$this->lavaHeight]);

        $bedrock = VanillaBlocks::BEDROCK();
        $lava = VanillaBlocks::LAVA();

        $center = new Vector2(0, 0);
        $mapSize = (EscapeTheLavaGenerator::MAP_SIZE - 5) ** 2;

        foreach($heights as $y) {
            ReplayStudio::getRecording($world)?->pushPacket(AreaFillBlockPacket::make($lava, new Vector3($baseX, $y, $baseZ), new Vector3($baseX + 16, $y, $baseZ + 16)));
            for($x = 0; $x < Chunk::EDGE_LENGTH; ++$x){
                $absoluteX = $baseX + $x;
                for($z = 0; $z < Chunk::EDGE_LENGTH; ++$z){
                    $absoluteZ = $baseZ + $z;
                    if($world->getBlockAt($absoluteX, $y, $absoluteZ)->isSameState($bedrock) || $center->distanceSquared(new Vector2($absoluteX, $absoluteZ)) > $mapSize) {
                        continue;
                    }
                    $world->setBlockAt($absoluteX, $y, $absoluteZ, $lava, false);
                }
            }
        }
    }
}