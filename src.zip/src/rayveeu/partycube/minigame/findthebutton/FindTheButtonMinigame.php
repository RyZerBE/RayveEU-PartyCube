<?php

declare(strict_types=1);

namespace rayveeu\partycube\minigame\findthebutton;

use minigame\player\MinigamePlayerType;
use pocketmine\block\Block;
use pocketmine\block\Button;
use pocketmine\block\VanillaBlocks;
use pocketmine\event\player\PlayerInteractEvent;
use pocketmine\item\Item;
use pocketmine\math\Vector3;
use pocketmine\player\Player;
use pocketmine\Server;
use pocketmine\world\particle\BlockBreakParticle;
use pocketmine\world\World;
use rayveeu\essentials\player\Session;
use rayveeu\essentials\util\TitleFormat;
use rayveeu\essentials\world\generator\VoidGenerator;
use rayveeu\partycube\minigame\findthebutton\generator\FindTheButtonGenerator;
use rayveeu\partycube\minigame\findthebutton\map\CaveFindTheButtonMap;
use rayveeu\partycube\minigame\findthebutton\map\FindTheButtonMap;
use rayveeu\partycube\minigame\Minigame;
use rayveeu\partycube\minigame\mlgrun\generator\MLGRunGenerator;
use rayveeu\partycube\minigame\mlgrun\map\MLGRunMap;
use rayveeu\partycube\PartyCube;
use rayveeu\partycube\util\ranking\HighestPointsRanking;
use rayveeu\partycube\util\ranking\LowestPointsRanking;
use rayveeu\partycube\util\ranking\Ranking;

class FindTheButtonMinigame extends Minigame{
    private Vector3 $button;

    /** @var Block[][]  */
    private array $reappearButtons = [];

    public function getName(): string{
        return "Find the Button";
    }

    public function getMapPool(): array{
        return [
            new CaveFindTheButtonMap(),
        ];
    }

    public function getInitialRankingType(): Ranking{
        return new LowestPointsRanking();
    }

    public function getItem(): Item{
        return VanillaBlocks::DARK_OAK_BUTTON()->asItem();
    }

    public function onQueuedPlayerTeleport(Player $player): void{
        $player->setNoClientPredictions();
    }

    public function onStart(): void{
        $this->button = $this->map->getRandomButton();
        foreach(PartyCube::getInstance()->getSessions() as $session) {
            $session->getPlayer()->setNoClientPredictions(false);
        }
    }

    protected function rankInRest(): void{
        foreach(PartyCube::getInstance()->getSessions() as $session) {
            $this->ranking->getPoints($session->getPlayer())->set($this->button->distance($session->getPlayer()->getPosition()));
        }
    }

    public function tick(int $tick): void{
        /** @var World $world */
        $world = $this->map->getWorld();

        $buttons = $this->reappearButtons[$tick] ?? [];
        foreach($buttons as $button) {
            $position = $button->getPosition();
            $world->setBlockAt($position->getFloorX(), $position->getFloorY(), $position->getFloorZ(), $button);
        }
        unset($this->reappearButtons[$tick]);

        if($tick % 20 === 0) {
            $timer = $this->getTimer()->get();
            if(($timer <= 270 && $timer % 60 === 0) || $timer <= 30) {
                $button = $this->button;
                foreach(PartyCube::getInstance()->getSessions() as $session) {
                    $session->sendTitle(TitleFormat::TOP_LEFT_1, "title.button_distance", [
                        "distance" => round($button->distance($session->getPlayer()->getPosition()))
                    ], 100);
                }
            }
        }
    }

    protected function isButton(Block $block): bool {
        return $block->getPosition()->floor()->equals($this->button);
    }

    public function onPlayerInteract(PlayerInteractEvent $event): void{
        $block = $event->getBlock();
        $player = $event->getPlayer();
        $session = Session::getNullSafe($player);
        $world = $player->getWorld();

        if($block instanceof Button) {
            if(!$this->isButton($block)) {
                $position = $block->getPosition();
                $world->addParticle($position, new BlockBreakParticle($block));
                $world->setBlockAt($position->getFloorX(), $position->getFloorY(), $position->getFloorZ(), VanillaBlocks::AIR());
                $session->playSound("random.fizz");

                $this->reappearButtons[Server::getInstance()->getTick() + 300][] = $block;
            } else {
                $this->ranking->fixPlacement($player);

                MinigamePlayerType::get($player)->setSpectator(true);

                PartyCube::getInstance()->broadcastMessage("message.player_found_button", [
                    "player" => $session->getDisplayName()
                ]);
            }
        }

        $event->cancel();
    }
}