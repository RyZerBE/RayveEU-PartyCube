<?php

declare(strict_types=1);

namespace rayveeu\partycube\minigame\findthebutton\generator;

use pocketmine\math\Facing;
use pocketmine\math\Vector2;
use pocketmine\math\Vector3;
use pocketmine\scheduler\AsyncTask;
use pocketmine\Server;
use pocketmine\utils\Config;
use pocketmine\world\format\Chunk;
use pocketmine\world\format\io\FastChunkSerializer;
use pocketmine\world\World;
use rayveeu\essentials\Essentials;
use rayveeu\partycube\minigame\findthebutton\FindTheButtonMinigame;
use pocketmine\world\format\PalettedBlockArray;

class FindTheButtonGenerator extends AsyncTask{
    public function __construct(
        private string $dungeon,
        private string $world,
    ){}

    public function onRun(): void{
        $config = new Config(Essentials::NETWORK_ROOT_PATH."Source/dungeons/".$this->dungeon."/rooms.json");

        /** @var Room[] $roomTree */
        $roomTree = [];

        $placeableRooms = [];

        foreach($config->get("rooms") as $id => $room) {
            $placeableRooms[$id] = new PlaceableRoom($room["facing"], (string)$id);
        }

        $this->setRoomAt($roomTree, new Room(new Vector2(0, 0), Facing::HORIZONTAL, $this->selectRoom($placeableRooms, Facing::HORIZONTAL, [], [])));
        $center = new Vector3(0, 0, 0);
        foreach(Facing::HORIZONTAL as $side) {
            $sideVector = $center->getSide($side);

            $roomsLeft = random_int(3, 6);

            $newRoom = $this->selectRoom($placeableRooms, [$side], Facing::HORIZONTAL, []);
            $this->generateRooms($roomTree, $placeableRooms, new Room(new Vector2($sideVector->x, $sideVector->z), $newRoom?->sides ?? Facing::HORIZONTAL, $newRoom), $roomsLeft);
        }

        $buttons = [];
        foreach($roomTree as $hash => $room) {
            $buttons[] = $config->getNested("rooms.".$room->placeableRoom->id.".buttons");
            $blocks = unserialize(file_get_contents(Essentials::NETWORK_ROOT_PATH."Source/dungeons/".$this->dungeon."/chunks/".$room->placeableRoom->id.".chunk"), [true]);

            var_dump($room->vector2->x.":".$room->vector2->y, $room->placeableRoom->sides);

            $chunk = new Chunk([], true);
            foreach($blocks as $blockHash => $blockStateId) {
                World::getBlockXYZ($blockHash, $x, $y, $z);
                $chunk->setBlockStateId($x, $y % 16, $z, $blockStateId);
            }

            $this->publishProgress([
                $hash,
                FastChunkSerializer::serializeTerrain($chunk),
            ]);
        }

        $this->setResult($buttons);
    }

    public function onProgressUpdate($progress): void{
        FindTheButtonMinigame::$chunks[$progress[0]] = FastChunkSerializer::deserializeTerrain($progress[1]);
    }

    public function onCompletion(): void{
        $world = Server::getInstance()->getWorldManager()->getWorldByName($this->world);
        if($world === null) {
            return;
        }
        foreach(FindTheButtonMinigame::$chunks as $hash => $chunk) {
            World::getXZ($hash, $chunkX, $chunkZ);

            $world->setChunk($chunkX, $chunkZ, $chunk);
        }
    }

    private function generateRooms(array &$rooms, array $placeableRooms, Room $room, int &$roomsLeft): void {
        $this->setRoomAt($rooms, $room);
        if(count($room->sides) <= 1) {
            return;
        }
        $roomsLeft--;
        foreach($room->sides as $side) {
            $forcedSides = [];
            $extraSides = [];
            $bannedSides = [];

            $vector = (new Vector3($room->vector2->x, 0, $room->vector2->y))->getSide($side);
            $collisionRoom = $this->getRoomAt($rooms, new Vector2($vector->x, $vector->z));
            if($collisionRoom !== null) {
                continue;
            }
            if($roomsLeft <= 0) {
                $newRoom = $this->selectRoomBySide($placeableRooms, $side);
            } else {
                foreach(Facing::HORIZONTAL as $facing) {
                    $sideVector = $vector->getSide($facing);
                    $sideRoom = $this->getRoomAt($rooms, new Vector2($sideVector->x, $sideVector->z));

                    $opposite = Facing::opposite($facing);
                    if($sideRoom === null) {
                        $extraSides[] = $opposite;
                    } elseif(!$sideRoom->hasSide($opposite)) {
                        $bannedSides[] = $opposite;
                    } else {
                        $forcedSides[] = $opposite;
                    }
                }
                $newRoom = $this->selectRoom($placeableRooms, $forcedSides, $extraSides, $bannedSides);
            }
            if($newRoom === null) {
                var_dump(array_map(function(int $side): string {
                    return Facing::toString($side);
                }, $forcedSides), array_map(function(int $side): string {
                    return Facing::toString($side);
                }, $extraSides), array_map(function(int $side): string {
                    return Facing::toString($side);
                }, $bannedSides));
                continue;
            }
            $this->generateRooms($rooms, $placeableRooms, new Room(new Vector2($vector->getFloorX(), $vector->getFloorZ()), $newRoom->sides, $newRoom), $roomsLeft);
        }
    }

    private function getRoomAt(array $rooms, Vector2 $vector2): ?Room {
        return $rooms[World::chunkHash($vector2->getFloorX(), $vector2->getFloorY())] ?? null;
    }

    private function setRoomAt(array &$rooms, Room $room): void {
        $vector2 = $room->vector2;
        $rooms[World::chunkHash($vector2->getFloorX(), $vector2->getFloorY())] = $room;
    }

    private function selectRoom(array $rooms, array $sides, array $extraSides, array $bannedSides): ?PlaceableRoom {
        $rooms = array_filter($rooms, function(PlaceableRoom $room) use ($sides, $extraSides, $bannedSides): bool {
            if(count($bannedSides) > 0) {
                foreach($bannedSides as $bannedSide) {
                    if($room->hasSide($bannedSide)) {
                        return false;
                    }
                }
            }
            return $room->hasSides($sides);
        });
        if(count($rooms) <= 0) {
            return null;
        }
        return $rooms[array_rand($rooms)];
    }

    private function selectRoomBySide(array $rooms, int $side): ?PlaceableRoom {
        $rooms = array_filter($rooms, function(PlaceableRoom $room) use ($side): bool {
            return count($room->sides) === 1 && $room->hasSide($side);
        });
        if(count($rooms) <= 0) {
            return null;
        }
        return $rooms[array_rand($rooms)];
    }
}