<?php

declare(strict_types=1);

namespace rayveeu\partycube\minigame\findthebutton\generator;

class PlaceableRoom{
    public function __construct(
        public array $sides,
        public string $id,
    ){}

    public function hasSide(int $side): bool {
        return in_array($side, $this->sides, true);
    }

    public function hasSides(array $sides): bool {
        foreach($sides as $side) {
            if(!$this->hasSide($side)) {
                return false;
            }
        }
        return true;
    }
}