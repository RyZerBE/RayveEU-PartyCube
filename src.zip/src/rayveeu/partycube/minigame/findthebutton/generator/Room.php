<?php

declare(strict_types=1);

namespace rayveeu\partycube\minigame\findthebutton\generator;

use pocketmine\math\Vector2;

class Room{
    public function __construct(
        public Vector2 $vector2,
        public array $sides,
        public PlaceableRoom $placeableRoom,
    ){}

    public function hasSide(int $side): bool {
        return in_array($side, $this->sides, true);
    }

    public function hasSides(array $sides): bool {
        foreach($sides as $side) {
            if(!$this->hasSide($side)) {
                return false;
            }
        }
        return true;
    }
}