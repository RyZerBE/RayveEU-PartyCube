<?php

declare(strict_types=1);

namespace rayveeu\partycube\minigame\findthebutton\map;

use rayveeu\essentials\util\SpawnPosition;

class CaveFindTheButtonMap extends FindTheButtonMap{
    public function getLevelName(): string{
        return "FindTheButton-1";
    }

    public function getSpawn(): SpawnPosition{
        return new SpawnPosition(-23.5, 95.1, -6.5, 45);
    }

    public function getCredits(): array{
        return ["Matze998"];
    }

    public function getDisplayName(): string{
        return "Cave";
    }
}