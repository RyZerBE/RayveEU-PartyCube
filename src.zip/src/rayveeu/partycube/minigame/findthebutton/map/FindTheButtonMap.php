<?php

declare(strict_types=1);

namespace rayveeu\partycube\minigame\findthebutton\map;

use minigame\map\StoredMap;
use pocketmine\block\Button;
use pocketmine\block\GlazedTerracotta;
use pocketmine\block\RuntimeBlockStateRegistry;
use pocketmine\block\VanillaBlocks;
use pocketmine\event\world\ChunkLoadEvent;
use pocketmine\math\Vector3;
use pocketmine\world\format\io\FastChunkSerializer;
use pocketmine\world\format\SubChunk;
use rayveeu\essentials\util\AsyncExecutor;

abstract class FindTheButtonMap extends StoredMap{
    /** @var Vector3[]  */
    private array $buttons = [];

    public function getRandomButton(): Vector3 {
        return $this->buttons[array_rand($this->buttons)];
    }

    public function onChunkLoad(ChunkLoadEvent $event): void{
        $chunk = FastChunkSerializer::serializeTerrain($event->getChunk());
        $chunkX = $event->getChunkX();
        $chunkZ = $event->getChunkZ();
        AsyncExecutor::submitAsyncTask(static function() use ($chunk, $chunkX, $chunkZ): array {
            $chunk = FastChunkSerializer::deserializeTerrain($chunk);
            $buttons = [];

            $baseX = $chunkX * 16;
            $baseZ = $chunkZ * 16;

            foreach($chunk->getSubChunks() as $id => $subChunk) {
                if($subChunk->isEmptyFast()) {
                    continue;
                }

                for($x = 0; $x <= 15; $x++) {
                    for($z = 0; $z <= 15; $z++) {
                        for($y = 0; $y <= SubChunk::EDGE_LENGTH; $y++) {
                            $block = $subChunk->getBlockStateId($x, $y, $z);
                            $block = RuntimeBlockStateRegistry::getInstance()->fromStateId($block);

                            $realY = $id * 16 + $y;
                            if($block instanceof Button) {
                                $buttons[] = new Vector3($baseX + $x, $realY, $baseZ + $z);
                            }
                        }
                    }
                }
            }
            return $buttons;
        }, function(array $buttons) use ($event): void {
            if(count($buttons) <= 0) {
                return;
            }
            shuffle($buttons);
            $chunks = array_chunk($buttons, (int)ceil(count($buttons) / 2));
            $buttons = array_shift($chunks) ?? [];

            $world = $event->getWorld();
            foreach($chunks as $chunk) {
                foreach($chunk as $vector3) {
                    $world->setBlockAt($vector3->x, $vector3->y, $vector3->z, VanillaBlocks::AIR());
                }
            }
            $this->buttons = array_merge($this->buttons, $buttons);
        });
    }
}