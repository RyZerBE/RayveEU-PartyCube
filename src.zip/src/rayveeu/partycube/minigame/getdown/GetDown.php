<?php

declare(strict_types=1);

namespace rayveeu\partycube\minigame\getdown;

use minigame\player\MinigamePlayerType;
use pocketmine\block\utils\DyeColor;
use pocketmine\block\VanillaBlocks;
use pocketmine\entity\effect\VanillaEffects;
use pocketmine\event\entity\EntityDamageEvent;
use pocketmine\event\player\PlayerMoveEvent;
use pocketmine\event\player\PlayerRespawnEvent;
use pocketmine\item\Item;
use pocketmine\math\Vector3;
use pocketmine\player\Player;
use pocketmine\Server;
use pocketmine\world\format\io\FastChunkSerializer;
use pocketmine\world\particle\AngryVillagerParticle;
use pocketmine\world\particle\HappyVillagerParticle;
use pocketmine\world\World;
use rayveeu\essentials\player\Session;
use rayveeu\essentials\util\BuilderUtils;
use rayveeu\essentials\util\WorldUtils;
use rayveeu\partycube\minigame\getdown\generator\GetDownGenerator;
use rayveeu\partycube\minigame\getdown\map\OceanGetDownMap;
use rayveeu\partycube\minigame\getdown\reward\BreakBlockReward;
use rayveeu\partycube\minigame\getdown\reward\JumpBoostReward;
use rayveeu\partycube\minigame\getdown\reward\LevitationReward;
use rayveeu\partycube\minigame\getdown\reward\RandomMessageReward;
use rayveeu\partycube\minigame\getdown\reward\RandomMotionReward;
use rayveeu\partycube\minigame\getdown\reward\RegenerationReward;
use rayveeu\partycube\minigame\getdown\reward\Reward;
use rayveeu\partycube\minigame\getdown\reward\SlowFallingReward;
use rayveeu\partycube\minigame\Minigame;
use rayveeu\partycube\PartyCube;
use rayveeu\partycube\util\ranking\LowestPointsRanking;
use rayveeu\partycube\util\ranking\Ranking;

class GetDown extends Minigame{
    /** @var Reward[]  */
    protected ?array $rewards = null;

    protected array $regenerateBlocks = [];

    public function getName(): string{
        return "Get Down";
    }

    public function getMapPool(): array{
        return [
            new OceanGetDownMap(),
        ];
    }

    public function getRewards(): array {
        return $this->rewards ??= [
            new JumpBoostReward(),
            new SlowFallingReward(),
            new RandomMessageReward(),
            new SlowFallingReward(),
            new BreakBlockReward(),
            new RandomMotionReward(),
            new RegenerationReward(),
            new LevitationReward(),
        ];
    }

    public function getInitialRankingType(): Ranking{
        return new LowestPointsRanking();
    }

    public function getItem(): Item{
        return VanillaBlocks::STAINED_GLASS()->setColor(DyeColor::MAGENTA())->asItem();
    }

    public function onMapInitialize(): void{
        $area = $this->map->getJumpArea();
        $chunks = [];
        foreach(WorldUtils::getTouchedChunks($this->map->getWorld(), $area) as $hash => $chunk) {
            if($chunk !== null) {
                $chunks[$hash] = FastChunkSerializer::serializeTerrain($chunk);
            }
        }
        Server::getInstance()->getAsyncPool()->submitTask(new GetDownGenerator($this->map->getWorld()?->getFolderName(), igbinary_serialize($chunks), igbinary_serialize($area)));
    }

    public function onGeneratorFinish(): void {
        $area = $this->map->getSpawnArea();
        /** @var World $world */
        $world = $this->map->getWorld();

        $air = VanillaBlocks::AIR();
        $barrier = VanillaBlocks::INVISIBLE_BEDROCK();

        for($y = (int)$area->minY; $y <= $area->maxY; $y++) {
            for($x = (int)$area->minX; $x <= $area->maxX; $x++) {
                if($world->getBlockAt($x, $y, (int)$area->minZ)->isSameState($air)) {
                    $world->setBlockAt($x, $y, (int)$area->minZ, $barrier);
                }
                if($world->getBlockAt($x, $y, (int)$area->maxZ)->isSameState($air)) {
                    $world->setBlockAt($x, $y, (int)$area->maxZ, $barrier);
                }
            }

            for($z = (int)$area->minZ; $z <= $area->maxZ; $z++) {
                if($world->getBlockAt((int)$area->minX, $y, $z)->isSameState($air)) {
                    $world->setBlockAt((int)$area->minX, $y, $z, $barrier);
                }
                if($world->getBlockAt((int)$area->maxX, $y, $z)->isSameState($air)) {
                    $world->setBlockAt((int)$area->maxX, $y, $z, $barrier);
                }
            }
        }
    }

    public function tick(int $tick): void{
        if(isset($this->regenerateBlocks[$tick])) {
            /** @var World $world */
            $world = $this->map->getWorld();
            foreach($this->regenerateBlocks[$tick] as $hash) {
                World::getBlockXYZ($hash, $x, $y, $z);
                if($world->getNearestEntity(new Vector3($x, $y + 1, $z), 2, Player::class) !== null) {
                    $this->regenerateBlocks[$tick + 5][] = $hash;
                    continue;
                }
                $world->setBlockAt($x, $y, $z, VanillaBlocks::GOLD());
            }
            unset($this->regenerateBlocks[$tick]);
        }
    }

    public function onStart(): void{
        $area = $this->map->getSpawnArea();
        BuilderUtils::replace($this->map->getWorld(), new Vector3($area->minX, $area->minY, $area->minZ), new Vector3($area->maxX, $area->maxY, $area->maxZ), VanillaBlocks::INVISIBLE_BEDROCK(), VanillaBlocks::AIR());
        foreach(PartyCube::getInstance()->getSessions() as $session) {
            $session->getPlayer()->noDamageTicks = 5;
        }
    }

    protected function rankInRest(): void{
        foreach(PartyCube::getInstance()->getSessions() as $session) {
            $this->ranking->getPoints($session->getPlayer())->set($session->getPlayer()->getLocation()->getFloorY());
        }
    }

    public function onEntityDamage(EntityDamageEvent $event): void{
        if(($event->getCause() === EntityDamageEvent::CAUSE_FALL) && $event->getEntity()->fallDistance < 3.5) {
            $event->cancel();
        }
    }

    public function onPlayerRespawn(PlayerRespawnEvent $event): void{
        $event->setRespawnPosition($this->map->getSpawn()->asLocation($this->map->getWorld()));
        $event->getPlayer()->noDamageTicks = 10;
    }

    public function onPlayerMove(PlayerMoveEvent $event): void{
        $player = $event->getPlayer();
        if(MinigamePlayerType::get($player)->isSpectator()) {
            return;
        }
        $world = $player->getWorld();
        $to = $event->getTo();
        $block = $world->getBlock($to->down());
        if($player->isOnGround()) {
            $session = Session::getNullSafe($player);
            if($block->isSameState(VanillaBlocks::GOLD())) {
                $rewards = $this->getRewards();
                $reward = $rewards[array_rand($rewards)];
                $position = $block->getPosition();

                $world->setBlock($position, VanillaBlocks::BEDROCK());
                $reward->activate($player, $block);
                if(!$reward->isNeutral()) {
                    if($reward->isBad()) {
                        $session->playSound("mob.villager.no");
                        $particle = new AngryVillagerParticle();
                    } else {
                        $session->playSound("random.orb", 1.0, 1.5);
                        $particle = new HappyVillagerParticle();
                    }
                    for($i = 0; $i <= 8; $i++) {
                        $world->addParticle($position->add(random_int(0, 10) / 11, random_int(0, 10) / 11, random_int(0, 10) / 11), $particle);
                    }
                }
                $this->regenerateBlocks[Server::getInstance()->getTick() + 200][] = World::blockHash($position->getFloorX(), $position->getFloorY(), $position->getFloorZ());
            } elseif($to->getY() <= $this->map->getWinHeight()) {
                $this->ranking->fixPlacement($player);
                $this->map->teleport($player);
                $session->reset();
                MinigamePlayerType::get($player)->setSpectator(true);

                PartyCube::getInstance()->broadcastMessage("message.player_finished", [
                    "player" => $session->getDisplayName()
                ]);
            }
        }

        $slowFalling = $player->getEffects()->get(VanillaEffects::LEVITATION());
        if($slowFalling !== null && $slowFalling->getAmplifier() < 0) {
            $player->resetFallDistance();
        }
    }
}