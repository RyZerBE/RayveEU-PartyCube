<?php

declare(strict_types=1);

namespace rayveeu\partycube\minigame\getdown\generator;

use pocketmine\block\utils\DyeColor;
use pocketmine\block\VanillaBlocks;
use pocketmine\math\Facing;
use pocketmine\math\Vector3;
use pocketmine\Server;
use pocketmine\world\format\io\FastChunkSerializer;
use pocketmine\world\World;
use rayveeu\partycube\minigame\MinigameManager;
use rayveeu\partycube\util\AsyncGenerator;

class GetDownGenerator extends AsyncGenerator{
    public function __construct(
        protected string $world,
        protected string $chunks,
        protected string $area
    ){}

    public function onRun(): void{
        $chunks = igbinary_unserialize($this->chunks);
        foreach($chunks as $hash => $chunk) {
            $chunks[$hash] = FastChunkSerializer::deserializeTerrain($chunk);
        }

        $air = VanillaBlocks::AIR();
        $special = VanillaBlocks::GOLD();
        $default = [VanillaBlocks::STAINED_GLASS(), VanillaBlocks::CONCRETE(), VanillaBlocks::STAINED_CLAY(), VanillaBlocks::SEA_LANTERN(), VanillaBlocks::WOOL()];

        $colors = DyeColor::getAll();

        $area = igbinary_unserialize($this->area);

        for($y = (int)$area->minY; $y <= (int)$area->maxY; $y++) {
            for($x = (int)$area->minX; $x <= (int)$area->maxX; $x++) {
                for($z = (int)$area->minZ; $z <= (int)$area->maxZ; $z++) {
                    //Validate if position is empty or is randomly used to place a block
                    if(random_int(0, 300) > 2) {
                        continue;
                    }

                    if(!$this->getBlock($x, $y, $z, $chunks)->isSameState($air)) {
                        continue;
                    }

                    $vector3 = new Vector3($x, $y, $z);
                    foreach(Facing::ALL as $facing) {
                        $side = $vector3->getSide($facing);
                        if(!$this->getBlock($side->getFloorX(), $side->getFloorY(), $side->getFloorZ(), $chunks)->isSameState($air)) {
                            continue 2;
                        }
                    }

                    //Choose block to place
                    if(random_int(0, 100) <= 1) {
                        $this->setBlock($x, $y, $z, $special, $chunks);
                    } else {
                        $color = $colors[array_rand($colors)];
                        $block = $default[array_rand($default)];
                        if(method_exists($block, "setColor")) {
                            $block->setColor($color);
                        }
                        $this->setBlock($x, $y, $z, $block, $chunks);
                    }
                }
            }
        }

        $result = [];
        foreach($chunks as $hash => $chunk) {
            $result[$hash] = FastChunkSerializer::serializeTerrain($chunk);
        }

        $this->setResult([
            $result
        ]);
    }

    public function onCompletion(): void{
        $world = Server::getInstance()->getWorldManager()->getWorldByName($this->world);
        if($world === null) {
            return;
        }
        $result = $this->getResult();

        foreach($result[0] as $hash => $chunk) {
            World::getXZ($hash, $chunkX, $chunkZ);
            $world->setChunk($chunkX, $chunkZ, FastChunkSerializer::deserializeTerrain($chunk));
        }

        MinigameManager::getCurrentNullSafe()->onGeneratorFinish();
    }
}