<?php

declare(strict_types=1);

namespace rayveeu\partycube\minigame\getdown\map;

use minigame\map\StoredMap;
use pocketmine\math\AxisAlignedBB;
use pocketmine\world\World;

abstract class GetDownMap extends StoredMap{
    abstract public function getJumpArea(): AxisAlignedBB;
    abstract public function getSpawnArea(): AxisAlignedBB;
    abstract public function getWinHeight(): int;

    public function getTime(): int{
        return World::TIME_NIGHT;
    }
}