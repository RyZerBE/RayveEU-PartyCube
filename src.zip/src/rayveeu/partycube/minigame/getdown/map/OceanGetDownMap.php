<?php

declare(strict_types=1);

namespace rayveeu\partycube\minigame\getdown\map;

use pocketmine\math\AxisAlignedBB;
use rayveeu\essentials\util\SpawnPosition;

class OceanGetDownMap extends GetDownMap{
    public function getLevelName(): string{
        return "GetDown-1";
    }

    public function getSpawn(): SpawnPosition{
        return new SpawnPosition(0.5, 106.1, 0.5, 0);
    }

    public function getCredits(): array{
        return ["zueinfxch"];
    }

    public function getDisplayName(): string{
        return "Ocean";
    }

    public function getJumpArea(): AxisAlignedBB{
        return new AxisAlignedBB(-30, 7, -30, 30, 100, 30);
    }

    public function getSpawnArea(): AxisAlignedBB{
        return new AxisAlignedBB( -3, 106, -3, 3, 111, 3);
    }

    public function getWinHeight(): int{
        return 4;
    }
}