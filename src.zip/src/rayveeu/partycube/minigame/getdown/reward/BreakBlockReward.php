<?php

declare(strict_types=1);

namespace rayveeu\partycube\minigame\getdown\reward;

use pocketmine\block\Block;
use pocketmine\block\VanillaBlocks;
use pocketmine\player\Player;
use pocketmine\world\particle\BlockBreakParticle;

class BreakBlockReward extends Reward{
    public function isBad(): bool{
        return true;
    }

    public function isNeutral(): bool{
        return true;
    }

    public function activate(Player $player, Block $block): void{
        $world = $player->getWorld();
        $position = $block->getPosition();
        $world->addParticle($position, new BlockBreakParticle($block));
        $world->setBlock($position, VanillaBlocks::AIR());

        $player->sendActionBarMessage("§l§4-§r §oOops! §r§l§4-");
    }
}