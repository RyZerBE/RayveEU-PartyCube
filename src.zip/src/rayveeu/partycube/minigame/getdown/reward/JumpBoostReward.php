<?php

declare(strict_types=1);

namespace rayveeu\partycube\minigame\getdown\reward;

use pocketmine\block\Block;
use pocketmine\entity\effect\EffectInstance;
use pocketmine\entity\effect\VanillaEffects;
use pocketmine\player\Player;

class JumpBoostReward extends Reward{
    public function isBad(): bool{
        return false;
    }

    public function activate(Player $player, Block $block): void{
        $player->getEffects()->add(new EffectInstance(VanillaEffects::JUMP_BOOST(), 20 * 10, 2, true));

        $player->sendActionBarMessage("§l§a-§r Jump Boost || §7[§r10s§7] §l§a-");
    }
}