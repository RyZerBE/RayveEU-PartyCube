<?php

declare(strict_types=1);

namespace rayveeu\partycube\minigame\getdown\reward;

use pocketmine\block\Block;
use pocketmine\entity\effect\EffectInstance;
use pocketmine\entity\effect\VanillaEffects;
use pocketmine\player\Player;

class LevitationReward extends Reward{
    public function isBad(): bool{
        return true;
    }

    public function activate(Player $player, Block $block): void{
        $player->getEffects()->add(new EffectInstance(VanillaEffects::LEVITATION(), 20 * 4, 3));

        $player->sendActionBarMessage("§l§4-§r Levitation ||| §7[§r4s§7] §l§4-");
    }
}