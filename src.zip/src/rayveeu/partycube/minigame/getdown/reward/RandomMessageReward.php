<?php

declare(strict_types=1);

namespace rayveeu\partycube\minigame\getdown\reward;

use pocketmine\block\Block;
use pocketmine\player\Player;

class RandomMessageReward extends Reward{
    public const MESSAGES = [
        "OK",
        "Aha",
        "Nope",
        "Mmmmm no",
        "Hi!",
        "I like trees!",
        "Cool",
        "...",
        "Hiiiii",
        "Luck?",
    ];

    public function isBad(): bool{
        return false;
    }

    public function isNeutral(): bool{
        return true;
    }

    public function activate(Player $player, Block $block): void{
        $player->sendActionBarMessage("§r§l§o".self::MESSAGES[array_rand(self::MESSAGES)]);
    }
}