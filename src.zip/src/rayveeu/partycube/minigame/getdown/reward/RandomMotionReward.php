<?php

declare(strict_types=1);

namespace rayveeu\partycube\minigame\getdown\reward;

use pocketmine\block\Block;
use pocketmine\math\Vector3;
use pocketmine\player\Player;
use rayveeu\essentials\music\GenericSounds;

class RandomMotionReward extends Reward{
    public function isBad(): bool{
        return true;
    }

    public function activate(Player $player, Block $block): void{
        $player->setMotion(new Vector3(random_int(-10, 10) / 5, random_int(-10, 10) / 5, random_int(-10, 10) / 5));
        GenericSounds::boost($player);

        $player->sendActionBarMessage("§l§4-§r §oWOOSH §r§l§4-");
    }
}