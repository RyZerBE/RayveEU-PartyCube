<?php

declare(strict_types=1);

namespace rayveeu\partycube\minigame\getdown\reward;

use pocketmine\block\Block;
use pocketmine\entity\effect\EffectInstance;
use pocketmine\entity\effect\VanillaEffects;
use pocketmine\player\Player;

class RegenerationReward extends Reward{
    public function isBad(): bool{
        return false;
    }

    public function activate(Player $player, Block $block): void{
        $player->getEffects()->add(new EffectInstance(VanillaEffects::REGENERATION(), 100, 2));

        $player->sendActionBarMessage("§l§a-§r Regeneration || §7[§r5s§7] §l§a-");
    }
}