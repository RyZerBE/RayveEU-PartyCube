<?php

declare(strict_types=1);

namespace rayveeu\partycube\minigame\getdown\reward;

use pocketmine\block\Block;
use pocketmine\player\Player;

abstract class Reward{
    abstract public function isBad(): bool;

    public function isNeutral(): bool {
        return false;
    }

    abstract public function activate(Player $player, Block $block): void;
}