<?php

declare(strict_types=1);

namespace rayveeu\partycube\minigame\getdown\reward;

use pocketmine\block\Block;
use pocketmine\entity\effect\EffectInstance;
use pocketmine\entity\effect\VanillaEffects;
use pocketmine\player\Player;
use ReflectionClass;

class SlowFallingReward extends Reward{
    public function isBad(): bool{
        return false;
    }

    public function activate(Player $player, Block $block): void{
        $effect = new EffectInstance(VanillaEffects::LEVITATION(), 20 * 5, 1);
        $reflection = new ReflectionClass($effect);
        $property = $reflection->getProperty("amplifier");
        $property->setAccessible(true);
        $property->setValue($effect, -4);

        $player->getEffects()->add($effect);

        $player->sendActionBarMessage("§l§a-§r Slow Falling || §7[§r5s§7] §l§a-");
    }
}