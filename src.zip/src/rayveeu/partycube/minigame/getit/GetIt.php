<?php

declare(strict_types=1);

namespace rayveeu\partycube\minigame\getit;

use minigame\player\MinigamePlayerType;
use minigame\util\Countdown;
use pocketmine\block\VanillaBlocks;
use pocketmine\event\entity\EntityDamageEvent;
use pocketmine\event\entity\EntityItemPickupEvent;
use pocketmine\event\inventory\CraftItemEvent;
use pocketmine\event\inventory\InventoryTransactionEvent;
use pocketmine\event\player\PlayerRespawnEvent;
use pocketmine\item\Item;
use pocketmine\math\AxisAlignedBB;
use pocketmine\math\Vector3;
use pocketmine\player\GameMode;
use pocketmine\player\Player;
use rayveeu\essentials\event\player\PlayerDeathEvent;
use rayveeu\essentials\player\Session;
use rayveeu\essentials\util\BuilderUtils;
use rayveeu\essentials\util\SpawnPosition;
use rayveeu\essentials\util\TitleFormat;
use rayveeu\partycube\minigame\getit\map\GetItMap;
use rayveeu\partycube\minigame\getit\map\VanillaGetItMap;
use rayveeu\partycube\minigame\Minigame;
use rayveeu\partycube\minigame\MinigameSettings;
use rayveeu\partycube\PartyCube;
use rayveeu\partycube\util\ranking\HighestPointsRanking;
use rayveeu\partycube\util\ranking\Ranking;

class GetIt extends Minigame{
    protected Item $task;

    protected array $check = [];

    private array $canTakeDamage = [];

    public function getName(): string{
        return "Get It";
    }

    public function getMapPool(): array{
        return [
            new VanillaGetItMap(new SpawnPosition(61.5, 177.1, -646.5, 0, 0), new AxisAlignedBB(
                57, 178, -650, 65, 180, -642
            ), "GetIt-1"),
        ];
    }

    public function getInitialRankingType(): Ranking{
        return new HighestPointsRanking();
    }

    public function getInitialSettings(): MinigameSettings{
        return new GetItSettings();
    }

    public function getItem(): Item{
        return VanillaBlocks::CHEST()->asItem();
    }

    public function initTimer(): void{
        $this->timer = new Countdown(60 * 3);
    }

    public function onStart(): void{
        /** @var GetItMap $map */
        $map = $this->getMap();

        $tasks = $map->getTasks();
        $this->task = $tasks[array_rand($tasks)];

        $items = array_values($map->getStartItems());
        foreach(PartyCube::getInstance()->getSessions() as $session) {
            $player = $session->getPlayer();
            $this->canTakeDamage[$player->getName()] = false;
            $player->getInventory()->setContents($items);
            $player->setGamemode(GameMode::SURVIVAL());
        }

        $area = $this->map->getSpawnArea();
        BuilderUtils::fill($this->map->getWorld(), new Vector3($area->minX, $area->minY, $area->minZ), new Vector3($area->maxX, $area->maxY, $area->maxZ), VanillaBlocks::AIR());
    }

    public function tick(int $tick): void{
        if($tick % 20 === 0) {
            PartyCube::getInstance()->broadcastTitle(TitleFormat::TOP_LEFT_1, $this->task->getVanillaName());//TODO: Translation
        }

        while($xboxId = array_shift($this->check)) {
            $session = Session::get($xboxId);
            if($session === null) {
                continue;
            }
            $player = $session->getPlayer();
            if($player->getInventory()->contains($this->task)) {
                $this->ranking->fixPlacement($player);

                Session::getNullSafe($player)->reset();
                $this->getMap()->teleport($player);
                MinigamePlayerType::get($player)->setSpectator(true);

                PartyCube::getInstance()->broadcastMessage("message.player_found_item", [
                    "player" => $session->getDisplayName()
                ]);
            }
        }
    }

    private function scheduleCheck(Player $player): void {
        $xboxId = $player->getXuid();
        if(in_array($xboxId, $this->check, true)) {
            return;
        }
        $this->check[] = $xboxId;
    }

    public function onEntityDamage(EntityDamageEvent $event): void{
        $player = $event->getEntity();
        if($player instanceof Player) {
            $name = $player->getName();

            if(!($this->canTakeDamage[$name] ?? true)) {
                $event->cancel();
            }

            if($event->getCause() === EntityDamageEvent::CAUSE_FALL) {
                $this->canTakeDamage[$name] = true;
            }
        }
    }

    public function onPlayerDeath(PlayerDeathEvent $event): void{
        $event->setKeepInventory(true);
        $event->setDrops([]);
    }

    public function onPlayerRespawn(PlayerRespawnEvent $event): void{
        $player = $event->getPlayer();
        $event->setRespawnPosition($this->map->getSpawn()->asLocation($player->getWorld()));
        $this->canTakeDamage[$player->getName()] = false;
    }

    public function onInventoryTransaction(InventoryTransactionEvent $event): void{
        $player = $event->getTransaction()->getSource();
        if(MinigamePlayerType::get($player)->isSpectator()) {
            return;
        }
        $this->scheduleCheck($player);
    }

    public function onCraftItem(CraftItemEvent $event): void{
        if(MinigamePlayerType::get($event->getPlayer())->isSpectator()) {
            return;
        }
        $this->scheduleCheck($event->getPlayer());
    }

    public function onEntityItemPickup(EntityItemPickupEvent $event): void{
        $player = $event->getEntity();
        if(!$player instanceof Player) {
            return;
        }
        if(MinigamePlayerType::get($player)->isSpectator()) {
            return;
        }
        $this->scheduleCheck($player);
    }
}