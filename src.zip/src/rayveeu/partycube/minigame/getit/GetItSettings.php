<?php

declare(strict_types=1);

namespace rayveeu\partycube\minigame\getit;

use rayveeu\partycube\minigame\MinigameSettings;

class GetItSettings extends MinigameSettings{
    public bool $damage = true;
    public bool $respawnAfterDeath = true;
    public bool $itemDrop = true;
    public bool $itemPickup = true;
    public bool $itemConsume = true;
    public bool $blockPlacement = true;
    public bool $blockDestruction = true;
    public bool $blockInteraction = true;
    public bool $blockUpdate = true;
    public bool $inventoryTransactions = true;
    public bool $crafting = true;
}