<?php

declare(strict_types=1);

namespace rayveeu\partycube\minigame\getit\map;

use minigame\map\StoredMap;
use pocketmine\item\Item;

abstract class GetItMap extends StoredMap{
    /**
     * @return Item[]
     */
    abstract public function getTasks(): array;

    public function getStartItems(): array {
        return [];
    }
}