<?php

declare(strict_types=1);

namespace rayveeu\partycube\minigame\getit\map;

use pocketmine\item\VanillaItems;
use pocketmine\math\AxisAlignedBB;
use rayveeu\essentials\util\SpawnPosition;

class VanillaGetItMap extends GetItMap{
    public function __construct(
        protected SpawnPosition $spawnPosition,
        protected AxisAlignedBB $spawnArea,
        protected string $levelName,
    ){}

    public function getSpawn(): SpawnPosition{
        return $this->spawnPosition;
    }

    public function getSpawnArea(): AxisAlignedBB{
        return $this->spawnArea;
    }

    public function getDisplayName(): string{
        return "GetIt";
    }

    public function getTasks(): array{
        return [
            VanillaItems::SPRUCE_SIGN(),
            VanillaItems::OAK_SIGN(),
            VanillaItems::IRON_INGOT(),
        ];
    }

    public function getLevelName(): string{
        return $this->levelName;
    }

    public function getCredits(): array{
        return [];
    }
}