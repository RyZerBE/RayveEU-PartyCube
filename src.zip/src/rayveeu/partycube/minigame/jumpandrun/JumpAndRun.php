<?php

declare(strict_types=1);

namespace rayveeu\partycube\minigame\jumpandrun;

use minigame\map\MapManager;
use minigame\player\MinigamePlayerType;
use pocketmine\block\VanillaBlocks;
use pocketmine\event\entity\EntityDamageEvent;
use pocketmine\event\player\PlayerMoveEvent;
use pocketmine\item\Item;
use pocketmine\item\VanillaItems;
use pocketmine\network\mcpe\protocol\types\entity\EntityMetadataProperties;
use pocketmine\network\mcpe\protocol\types\entity\FloatMetadataProperty;
use pocketmine\player\Player;
use rayveeu\essentials\player\Session;
use rayveeu\essentials\util\cache\CacheTrait;
use rayveeu\essentials\util\math\Math;
use rayveeu\essentials\util\SpawnPosition;
use rayveeu\partycube\minigame\jumpandrun\map\SpeedRunJumpAndRunMap;
use rayveeu\partycube\minigame\Minigame;
use rayveeu\partycube\PartyCube;
use rayveeu\partycube\util\ranking\LowestPointsRanking;
use rayveeu\partycube\util\ranking\Ranking;

class JumpAndRun extends Minigame{
    use CacheTrait;

    private const LAST_CHECKPOINT = "_last_checkpoint";

    public function getName(): string{
        return "Jump and Run";
    }

    public function getMapPool(): array{
        return [
            new SpeedRunJumpAndRunMap(),
        ];
    }

    public function getInitialRankingType(): Ranking{
        return new LowestPointsRanking();
    }

    public function getItem(): Item{
        return VanillaItems::LEATHER_BOOTS();
    }

    protected function rankInRest(): void{
        $middle = Math::getMiddle($this->map->getFinishArea());
        foreach(PartyCube::getInstance()->getSessions() as $session) {
            $player = $session->getPlayer();
            $this->ranking->getPoints($player)->set($player->getLocation()->distance($middle));
        }
    }

    public function onQueuedPlayerTeleport(Player $player): void{
        if(MinigamePlayerType::get($player)->isSpectator()) {
            return;
        }
        $player->setNoClientPredictions();
    }

    public function onStart(): void{
        $this->getCache()->setAll([]);

        $sessions = PartyCube::getInstance()->getSessions();
        foreach($sessions as $session) {
            $player = $session->getPlayer();
            $player->setNoClientPredictions(false);
            MapManager::getCurrentMapNullSafe()->teleport($player);
            foreach($sessions as $playerSession) {
                if($playerSession === $session) {
                    continue;
                }
                $playerSession->getPlayer()->sendData([$player], [
                    EntityMetadataProperties::SCALE => new FloatMetadataProperty(0.5)
                ]);
            }
        }
    }

    public function tick(int $tick): void{
        if($tick % 20 === 0) {
            $sessions = PartyCube::getInstance()->getSessions();
            foreach($sessions as $session) {
                $player = $session->getPlayer();
                foreach($sessions as $playerSession) {
                    if($playerSession === $session) {
                        continue;
                    }
                    $playerSession->getPlayer()->sendData([$player], [
                        EntityMetadataProperties::SCALE => new FloatMetadataProperty(0.5)
                    ]);
                }
            }
        }
    }

    public function onPlayerMove(PlayerMoveEvent $event): void{
        $player = $event->getPlayer();
        $type = MinigamePlayerType::get($player);
        if($type->isSpectator()) {
            return;
        }
        $session = Session::getNullSafe($player);
        $to = $event->getTo();

        if($player->isOnFire()) {
            $player->extinguish();
        }

        $world = $player->getWorld();
        if($player->isOnGround()) {
            $cache = $this->getCache();
            $key = $player->getName().self::LAST_CHECKPOINT;
            if($world->getBlock($to)->isSameState(VanillaBlocks::WEIGHTED_PRESSURE_PLATE_LIGHT())) {
                /** @var SpawnPosition|null $last */
                $last = $cache->get($key);
                if($last === null || !$last->floor()->equals($to->floor())) {
                    $session->playSound("random.orb", 1.0, 0.5);
                    $session->sendActionBarMessage("tip.checkpoint_set");

                    $cache->set($key, new SpawnPosition($to->getFloorX() + 0.5, $to->getFloorY(), $to->getFloorZ() + 0.5, Math::lowestDiff($player->getLocation()->getYaw(), [
                        0, 45, 90, 135, 180, 225, 270, 315, 360
                    ])->value));
                }
            }
        } else if($player->fallDistance > 5) {
            $x = $to->getFloorX();
            $y = $to->getFloorY();
            $z = $to->getFloorZ();
            $air = VanillaBlocks::AIR();
            for($ySide = $y; $ySide >= ($y - 10); $ySide--) {
                if(!$world->getBlockAt($x, $y, $z)->isSameState($air)) {
                    return;
                }
            }
            $player->attack(new EntityDamageEvent($player, EntityDamageEvent::CAUSE_VOID, 999999));
        }

        if($this->map->getFinishArea()->isVectorInside($to)) {
            $this->ranking->fixPlacement($player);

            $session->reset();

            $type->setSpectator(true);

            PartyCube::getInstance()->broadcastMessage("message.player_finished", [
                "player" => $session->getDisplayName()
            ]);

            $this->map->teleport($player);
        }
    }

    public function onEntityDamage(EntityDamageEvent $event): void{
        $event->cancel();
        if($event->getCause() === EntityDamageEvent::CAUSE_VOID) {
            $player = $event->getEntity();
            if(!$player instanceof Player) {
                return;
            }
            if(MinigamePlayerType::get($player)->isSpectator()) {
                return;
            }
            $cache = $this->getCache();
            $key = $player->getName().self::LAST_CHECKPOINT;
            if($cache->exists($key)) {
                $cache->get($key)->teleport($player);
            } else {
                $this->map->teleport($player);
            }
            Session::getNullSafe($player)->playSound("block.false_permissions", 1.0, 0.6);
        }
    }
}