<?php

declare(strict_types=1);

namespace rayveeu\partycube\minigame\jumpandrun\map;

use minigame\map\FlatMapRemover;
use minigame\map\StoredMap;
use pocketmine\math\AxisAlignedBB;

abstract class JumpAndRunMap extends StoredMap implements FlatMapRemover{
    abstract public function getFinishArea(): AxisAlignedBB;
}