<?php

declare(strict_types=1);

namespace rayveeu\partycube\minigame\jumpandrun\map;

use pocketmine\event\player\PlayerMoveEvent;
use pocketmine\math\AxisAlignedBB;
use rayveeu\essentials\player\Session;
use rayveeu\essentials\util\SpawnPosition;

class SpeedRunJumpAndRunMap extends JumpAndRunMap{
    private ?AxisAlignedBB $portalArea = null;
    private ?SpawnPosition $portalSpawn = null;

    public function getFinishArea(): AxisAlignedBB{
        return new AxisAlignedBB(-10, 115, -136, -4, 123, -130);
    }

    public function getLevelName(): string{
        return "JumpAndRun-1";
    }

    public function getSpawn(): SpawnPosition{
        return new SpawnPosition(0.5, 100.1, 0.5, 180);
    }

    public function getCredits(): array{
        return ["zueinfxch"];
    }

    public function getDisplayName(): string{
        return "Speed Run";
    }

    public function getPortalArea(): AxisAlignedBB{
        return $this->portalArea ??= new AxisAlignedBB(-10, 119, -119, -7, 121, -117);
    }

    public function getPortalSpawn(): SpawnPosition {
        return $this->portalSpawn ??= new SpawnPosition(-7.5, 111.1, -120.5, 180);
    }

    public function onPlayerMove(PlayerMoveEvent $event): void{
        $player = $event->getPlayer();
        if($this->getPortalArea()->isVectorInside($event->getTo())) {
            $this->getPortalSpawn()->teleport($player);
            Session::getNullSafe($player)->playSound("portal.travel", 1.0, 1.2);
        }
    }
}