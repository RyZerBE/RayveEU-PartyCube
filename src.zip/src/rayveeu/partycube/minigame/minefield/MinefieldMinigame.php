<?php

declare(strict_types=1);

namespace rayveeu\partycube\minigame\minefield;

use minigame\map\Map;
use minigame\player\MinigamePlayerType;
use pocketmine\block\VanillaBlocks;
use pocketmine\block\WeightedPressurePlate;
use pocketmine\block\WeightedPressurePlateHeavy;
use pocketmine\event\player\PlayerMoveEvent;
use pocketmine\item\Item;
use pocketmine\math\Axis;
use pocketmine\math\Vector3;
use pocketmine\Server;
use pocketmine\world\particle\BlockBreakParticle;
use pocketmine\world\particle\ExplodeParticle;
use rayveeu\essentials\player\Session;
use rayveeu\essentials\util\BuilderUtils;
use rayveeu\partycube\minigame\minefield\generator\MinefieldGenerator;
use rayveeu\partycube\minigame\minefield\map\MansionMinefieldMap;
use rayveeu\partycube\minigame\minefield\map\MinefieldMap;
use rayveeu\partycube\minigame\Minigame;
use rayveeu\partycube\PartyCube;
use rayveeu\partycube\util\ranking\HighestPointsRanking;
use rayveeu\partycube\util\ranking\LowestPointsRanking;
use rayveeu\partycube\util\ranking\Ranking;

class MinefieldMinigame extends Minigame{
    public function getName(): string{
        return "Minefield";
    }

    public function getMapPool(): array{
        return [
            new MansionMinefieldMap(),
        ];
    }

    public function getInitialRankingType(): Ranking{
        return $this->getMap()->getAxis() === null ? new HighestPointsRanking() : new LowestPointsRanking();
    }

    public function getItem(): Item{
        return VanillaBlocks::WEIGHTED_PRESSURE_PLATE_HEAVY()->asItem();
    }

    /**
     * @return MinefieldMap
     */
    public function getMap(): Map{
        return parent::getMap();
    }

    public function onMapInitialize(): void{
        Server::getInstance()->getAsyncPool()->submitTask(new MinefieldGenerator($this->map->getLevelName(), $this->getMap()->getMinefieldArea()));
    }

    protected function rankInRest(): void{
        $map = $this->getMap();
        $goal = $map->getGoalArea();
        $axis = $map->getAxis();
        foreach(PartyCube::getInstance()->getSessions() as $session) {
            $player = $session->getPlayer();
            $position = $player->getPosition();
            $this->ranking->getPoints($player)->set(match ($axis) {
                Axis::X => abs($goal->minX - $position->getX()),
                Axis::Z => abs($goal->minZ - $position->getZ()),
                default => $position->distance($map->getSpawn())
            });
        }
    }

    public function onStart(): void{
        $map = $this->getMap();
        $startArea = $map->getStartBorderArea();

        BuilderUtils::fill($map->getWorld(), new Vector3($startArea->minX, $startArea->minY, $startArea->minZ), new Vector3($startArea->maxX, $startArea->maxY, $startArea->maxZ), VanillaBlocks::AIR());
    }

    public function onPlayerMove(PlayerMoveEvent $event): void{
        $player = $event->getPlayer();
        if(MinigamePlayerType::get($player)->isSpectator()) {
            return;
        }
        $session = Session::getNullSafe($player);
        $to = $event->getTo();
        $map = $this->getMap();

        if($player->isOnGround()) {
            $world = $player->getWorld();
            $block = $world->getBlock($to);
            if($block instanceof WeightedPressurePlate) {
                $axis = $map->getAxis();
                if($axis !== null) {
                    $spawn = $this->map->getSpawn();

                    $session->playSound("random.explode", 1.0, 0.7);
                    $player->teleport($spawn->withComponents(($axis === Axis::X ? $spawn->getX() : $to->getFloorX() + 0.5), null, ($axis === Axis::Z ? $spawn->getZ() : $to->getFloorZ() + 0.5)), $spawn->getYaw(), 0);
                    $session->playSound("random.explode", 1.0, 0.7);

                    $world->addParticle($to, new ExplodeParticle());
                }

                if($block instanceof WeightedPressurePlateHeavy) {
                    $world->setBlock($to, VanillaBlocks::WEIGHTED_PRESSURE_PLATE_LIGHT());
                } else {
                    $world->setBlock($to, VanillaBlocks::AIR());
                }
                $world->addParticle($to, new BlockBreakParticle($block));
            }
        }

        if($map->getGoalArea()->isVectorInside($to)) {
            $this->ranking->fixPlacement($player);
            MinigamePlayerType::get($player)->setSpectator(true);

            PartyCube::getInstance()->broadcastMessage("message.player_finished", [
                "player" => $session->getDisplayName()
            ]);
        }
    }
}