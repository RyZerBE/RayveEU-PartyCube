<?php

declare(strict_types=1);

namespace rayveeu\partycube\minigame\minefield\generator;

use pocketmine\block\Block;
use pocketmine\block\RuntimeBlockStateRegistry;
use pocketmine\block\VanillaBlocks;
use pocketmine\block\WeightedPressurePlate;
use pocketmine\math\AxisAlignedBB;
use pocketmine\scheduler\AsyncTask;
use pocketmine\Server;
use pocketmine\world\format\Chunk;
use pocketmine\world\format\io\FastChunkSerializer;
use pocketmine\world\World;

class MinefieldGenerator extends AsyncTask{
    private string $chunks;
    private string $area;

    public function __construct(
        private string        $levelName,
        AxisAlignedBB $area
    ){
        $world = Server::getInstance()->getWorldManager()->getWorldByName($this->levelName);

        $chunks = [];
        for($chunkX = $area->minX >> 4; $chunkX <= $area->maxX >> 4; $chunkX++) {
            for($chunkZ = $area->minZ >> 4; $chunkZ <= $area->maxZ >> 4; $chunkZ++) {
                $chunk = $world?->loadChunk($chunkX, $chunkZ);
                if($chunk === null) {
                    continue;
                }
                $chunks[World::chunkHash($chunkX, $chunkZ)] = FastChunkSerializer::serializeTerrain($chunk);
            }
        }
        $this->area = igbinary_serialize($area);
        $this->chunks = igbinary_serialize($chunks);
    }

    public function onRun(): void{
        $chunks = igbinary_unserialize($this->chunks);
        foreach($chunks as $hash => $chunk) {
            $chunks[$hash] = FastChunkSerializer::deserializeTerrain($chunk);
        }
        $area = igbinary_unserialize($this->area);

        $air = VanillaBlocks::AIR();
        $plate = VanillaBlocks::WEIGHTED_PRESSURE_PLATE_HEAVY()->getStateId();

        for($x = $area->minX; $x <= $area->maxX; $x++) {
            for($z = $area->minZ; $z <= $area->maxZ; $z++) {
                for($y = $area->minY; $y <= $area->maxY; $y++) {
                    $block = $this->getBlockAt($chunks, $x, $y, $z);
                    if($block->isSameState($air) && $this->getBlockAt($chunks, $x, $y - 1, $z)->isFullCube()) {
                        $around = $this->getPlatesAround($chunks, $x, $y, $z);
                        if($around > 5 || random_int(0, 1000) >= 500) {
                            continue;
                        }
                        $this->getChunk($chunks, $x, $z)?->setBlockStateId((int)($x % 16), (int)$y, (int)($z % 16), $plate);
                        break;
                    }
                }
            }
        }

        foreach($chunks as $hash => $chunk) {
            $chunks[$hash] = FastChunkSerializer::serializeTerrain($chunk);
        }
        $this->setResult($chunks);
    }

    public function onCompletion(): void{
        $world = Server::getInstance()->getWorldManager()->getWorldByName($this->levelName);
        if($world === null) {
            return;
        }
        $chunks = $this->getResult();
        foreach($chunks as $hash => $chunk) {
            $chunk = FastChunkSerializer::deserializeTerrain($chunk);
            World::getXZ($hash, $chunkX, $chunkZ);
            $world->setChunk($chunkX, $chunkZ, $chunk);
        }
    }

    private function getPlatesAround(array $chunks, float $x, float $y, float $z): int {
        $count = 0;
        for($xSide = -1; $xSide <= 1; $xSide++) {
            for($zSide = -1; $zSide <= 1; $zSide++) {
                if($this->getBlockAt($chunks, $x + $xSide, $y, $z + $zSide) instanceof WeightedPressurePlate) {
                    $count++;
                }
            }
        }
        return $count;
    }

    private function getBlockAt(array $chunks, float $x, float $y, float $z): Block {
        $chunk = $this->getChunk($chunks, (int)$x, (int)$z);
        if($chunk === null) {
            return VanillaBlocks::AIR();
        }
        return RuntimeBlockStateRegistry::getInstance()->fromStateId($chunk->getBlockStateId($x % 16, (int)$y, $z % 16));
    }

    private function getChunk(array $chunks, float $x, float $z): ?Chunk {
        return $chunks[World::chunkHash($x >> 4, $z >> 4)] ?? null;
    }
}