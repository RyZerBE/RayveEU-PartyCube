<?php

declare(strict_types=1);

namespace rayveeu\partycube\minigame\minefield\map;

use pocketmine\math\Axis;
use pocketmine\math\AxisAlignedBB;
use rayveeu\essentials\util\math\Math;
use rayveeu\essentials\util\SpawnPosition;

class MansionMinefieldMap extends MinefieldMap{
    private AxisAlignedBB $minefieldArea;
    private AxisAlignedBB $goalArea;
    private AxisAlignedBB $startBorder;

    public function getLevelName(): string{
        return "Minefield-1";
    }

    public function getSpawn(): SpawnPosition{
        return new SpawnPosition(63.5, 4.1, -58.5, 90);
    }

    public function getCredits(): array{
        return ["zueinfxch"];
    }

    public function getDisplayName(): string{
        return "Mansion";
    }

    public function getAxis(): ?int{
        return Axis::X;
    }

    public function getMinefieldArea(): AxisAlignedBB{
        return $this->minefieldArea ??= Math::makeAxisAlignedBB(60, 3, -41, 16, 5, -76);
    }

    public function getGoalArea(): AxisAlignedBB{
        return $this->goalArea ??= Math::makeAxisAlignedBB(15, 3, -76, 11, 8, -41);
    }

    public function getStartBorderArea(): AxisAlignedBB{
        return $this->startBorder ??= Math::makeAxisAlignedBB(61, 4, -76, 61, 8, -41);
    }
}