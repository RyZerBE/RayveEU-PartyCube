<?php

declare(strict_types=1);

namespace rayveeu\partycube\minigame\minefield\map;

use minigame\map\StoredMap;
use pocketmine\math\AxisAlignedBB;
use rayveeu\essentials\util\SpawnPosition;

abstract class MinefieldMap extends StoredMap{
    abstract public function getAxis(): ?int;

    abstract public function getMinefieldArea(): AxisAlignedBB;

    abstract public function getGoalArea(): AxisAlignedBB;

    abstract public function getStartBorderArea(): AxisAlignedBB;
}