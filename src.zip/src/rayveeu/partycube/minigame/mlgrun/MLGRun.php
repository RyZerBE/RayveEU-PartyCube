<?php

declare(strict_types=1);

namespace rayveeu\partycube\minigame\mlgrun;

use minigame\player\MinigamePlayerType;
use pocketmine\block\Block;
use pocketmine\block\VanillaBlocks;
use pocketmine\event\block\BlockPlaceEvent;
use pocketmine\event\player\PlayerInteractEvent;
use pocketmine\event\player\PlayerMoveEvent;
use pocketmine\item\Item;
use pocketmine\math\Vector3;
use pocketmine\player\GameMode;
use pocketmine\player\Player;
use pocketmine\Server;
use rayveeu\essentials\player\Session;
use rayveeu\essentials\util\BuilderUtils;
use rayveeu\essentials\util\SpawnPosition;
use rayveeu\essentials\world\generator\VoidGenerator;
use rayveeu\partycube\minigame\Minigame;
use rayveeu\partycube\minigame\mlgrun\generator\MLGRunGenerator;
use rayveeu\partycube\minigame\mlgrun\map\MLGRunMap;
use rayveeu\partycube\PartyCube;
use rayveeu\partycube\util\PlayerIdTrait;
use rayveeu\partycube\util\ranking\HighestPointsRanking;
use rayveeu\partycube\util\ranking\Ranking;

class MLGRun extends Minigame{
    use PlayerIdTrait;

    public const PARKOUR_LENGTH = 150;

    public int $deathHeight = -1;
    public int $goalZ = -1;

    /** @var Block[][]  */
    private array $blocks = [];

    public function getName(): string{
        return "MLGRun";
    }

    public function getMapPool(): array{
        return [
            new MLGRunMap("MLGRun", VoidGenerator::class),
        ];
    }

    public function getItem(): Item{
        return VanillaBlocks::SANDSTONE()->asItem();
    }

    public function getInitialRankingType(): Ranking{
        return new HighestPointsRanking();
    }

    public function onMapInitialize(): void{
        Server::getInstance()->getAsyncPool()->submitTask(new MLGRunGenerator($this->getMap()->getLevelName(), PartyCube::getInstance()->getMaxPlayers()));
    }

    public function onLoad(): void{
        $this->resetIds();
    }

    public function onStart(): void{
        for($modules = 1; $modules <= PartyCube::getInstance()->getMaxPlayers(); $modules++) {
            BuilderUtils::fill($this->getMap()->getWorld(), new Vector3(12 + (($modules - 1) * 32), 103, 13), new Vector3(4 + (($modules - 1) * 32), 108, 13), VanillaBlocks::AIR());
        }

        $sandstone = VanillaBlocks::SANDSTONE()->asItem()->setCount(64);
        foreach(PartyCube::getInstance()->getSessions() as $session) {
            $player = $session->getPlayer();

            $player->setGamemode(GameMode::SURVIVAL());
            $player->getInventory()->setItemInHand($sandstone);
        }
    }

    protected function rankInRest(): void{
        foreach(PartyCube::getInstance()->getSessions() as $session) {
            $this->ranking->getPoints($session->getPlayer())->set($session->getPlayer()->getLocation()->getFloorZ());
        }
    }

    public function getSpawnFor(Player $player): SpawnPosition{
        if(MinigamePlayerType::get($player)->isSpectator()) {
            return $this->map->getSpawn();
        }
        $spawn = $this->map->getSpawn();
        $spawn->x = 8 + ($this->getId($player) * 32);
        return $spawn;
    }

    protected function addBlock(Player $player, Block $block): void {
        $this->blocks[$player->getXuid()][] = $block;
    }

    protected function resetBlocks(Player $player): void {
        $world = $this->map->getWorld();
        foreach($this->blocks[$player->getXuid()] ?? [] as $block) {
            $world?->setBlock($block->getPosition(), VanillaBlocks::AIR());
        }
    }

    public function onBlockPlace(BlockPlaceEvent $event): void{
        $required = VanillaBlocks::HARDENED_CLAY();

        $player = $event->getPlayer();
        $item = $event->getItem();

        $blocks = $event->getTransaction()->getBlocks();
        foreach($blocks as [$x, $y, $z, $block]) {
            $block = $player->getWorld()->getBlockAt($x, $y, $z);
            foreach($block->getAllSides() as $side) {
                if($side->isSameState($required)) {
                    $player->getInventory()->setItemInHand($item->setCount(64));
                    $this->addBlock($player, $block);
                    return;
                }
            }
        }
        $event->cancel();
    }

    public function onPlayerInteract(PlayerInteractEvent $event): void{
    }

    public function onPlayerMove(PlayerMoveEvent $event): void{
        $player = $event->getPlayer();
        if(MinigamePlayerType::get($player)->isSpectator()) {
            return;
        }
        $to = $event->getTo();
        if($to->getY() <= $this->deathHeight) {
            $this->getSpawnFor($player)->teleport($player, $this->map->getWorld());
            $this->resetBlocks($player);
        }
        if($player->isOnGround() && $to->getZ() >= $this->goalZ) {
            Session::getNullSafe($player)->reset();
            $this->ranking->fixPlacement($player);
            MinigamePlayerType::get($player)->setSpectator(true);

            PartyCube::getInstance()->broadcastMessage("message.player_finished", [
                "player" => Session::getNullSafe($player)->getDisplayName()
            ]);
        }
    }
}