<?php

declare(strict_types=1);

namespace rayveeu\partycube\minigame\mlgrun\generator;

use pocketmine\block\utils\DyeColor;
use pocketmine\block\VanillaBlocks;
use pocketmine\math\Vector3;
use pocketmine\Server;
use pocketmine\world\format\io\FastChunkSerializer;
use pocketmine\world\World;
use rayveeu\partycube\minigame\MinigameManager;
use rayveeu\partycube\minigame\mlgrun\MLGRun;
use rayveeu\partycube\util\AsyncGenerator;

class MLGRunGenerator extends AsyncGenerator{
    public function __construct(
        protected string $world,
        protected int $modules,
    ){}

    public function onRun(): void{
        $chunks = [];

        $this->fill(new Vector3(3, 103, 9), new Vector3(13, 108, 13), [VanillaBlocks::INVISIBLE_BEDROCK()], $chunks);
        $this->fill(new Vector3(4, 104, 8), new Vector3(12, 107, 12), [VanillaBlocks::AIR()], $chunks);
        $this->fill(new Vector3(4, 100, 8), new Vector3(12, 103, 12), [VanillaBlocks::CONCRETE()], $chunks);

        $x = 8;
        $y = 103;
        $z = 12;

        $lowestY = 100;

        while(true) {
            $this->generateJump($x, $y, $z);
            $this->placeCube($x, $y, $z, $chunks);

            if($lowestY > $y) {
                $lowestY = $y;
            }

            if($z > MLGRun::PARKOUR_LENGTH) {
                $z += random_int(2, 4);

                $this->fill(new Vector3($x - 6, $y - 2, $z), new Vector3($x + 6, $y, $z + 6), [VanillaBlocks::CONCRETE()->setColor(DyeColor::WHITE())], $chunks);
                break;
            }
        }

        $result = [];
        foreach($chunks as $hash => $chunk) {
            $result[$hash] = FastChunkSerializer::serializeTerrain($chunk);
        }

        $this->setResult([
            $result,
            $z,
            $lowestY - 5
        ]);
    }

    public function onCompletion(): void{
        $world = Server::getInstance()->getWorldManager()->getWorldByName($this->world);
        if($world === null) {
            return;
        }
        $result = $this->getResult();

        foreach($result[0] as $hash => $chunk) {
            World::getXZ($hash, $chunkX, $chunkZ);
            for($modules = 1; $modules <= $this->modules; $modules++) {
                $world->setChunk($chunkX + (($modules - 1) * 2), $chunkZ, FastChunkSerializer::deserializeTerrain($chunk));
            }
        }
        /** @var MLGRun $minigame */
        $minigame = MinigameManager::getCurrentNullSafe();
        $minigame->goalZ = $result[1];
        $minigame->deathHeight = $result[2];
    }

    protected function placeCube(int &$x, int &$y, int &$z, array &$chunks): void {
        $xSize = random_int(2, 5);

        $xMin = $x - ($xSize / 2);
        $xMax = $x + ($xSize / 2);
        $yMin = $y - 1;
        $yMax = $y + random_int(1, 5);
        $zMin = $z;
        $zMax = $z + random_int(2, 5);

        $colors = DyeColor::getAll();
        $color = $colors[array_rand($colors)];

        $concrete = VanillaBlocks::CONCRETE()->setColor($color);
        $terracotta = VanillaBlocks::HARDENED_CLAY();

        $this->fill(new Vector3($xMin, $yMin, $zMin), new Vector3($xMax, $yMax, $zMax), [$concrete], $chunks);
        $this->fill(new Vector3($xMin, $yMin, $z), new Vector3($xMax, $yMax, $z), [$terracotta], $chunks);
        $this->fill(new Vector3($xMin, $yMin, $zMax), new Vector3($xMax, $yMax, $zMax), [$terracotta], $chunks);

        $z = $zMax;
        $y = $yMax;
    }

    protected function generateJump(int &$x, int &$y, int &$z): void {
        $xJump = random_int(-3, 3);
        $yJump = random_int(-5, 1);
        $zJump = random_int(3, 6);

        $x += $xJump;
        if($x > 16) {
            $x = 16;
        } elseif($x < 4) {
            $x = 4;
        }

        if($zJump >= 5 && $yJump >= 1) {
            $yJump = random_int(-4, 0);
        }

        if($yJump <= -2) {
            $zJump += max(0, random_int(-2, (abs($yJump) - 2)));
        }

        $y += $yJump;
        if($y < 0) {
            $y = 0;
        } elseif($y > 200) {
            $y = 200;
        }

        $z += $zJump;
    }
}