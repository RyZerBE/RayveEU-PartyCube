<?php

declare(strict_types=1);

namespace rayveeu\partycube\minigame\mlgrun\map;

use minigame\map\GeneratedMap;
use rayveeu\essentials\util\SpawnPosition;

class MLGRunMap extends GeneratedMap{
    public function getSpawn(): SpawnPosition{
        return new SpawnPosition(8, 104.1, 10, 0);
    }

    public function getDisplayName(): string{
        return "MLGRun";
    }
}