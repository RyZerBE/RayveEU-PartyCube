<?php

declare(strict_types=1);

namespace rayveeu\partycube\minigame\paintball;

use customiesdevs\customies\item\CustomiesItemFactory;
use minigame\player\MinigamePlayerType;
use minigame\util\Countdown;
use pocketmine\block\VanillaBlocks;
use pocketmine\event\entity\EntityDamageByChildEntityEvent;
use pocketmine\event\entity\EntityDamageByEntityEvent;
use pocketmine\event\entity\EntityDamageEvent;
use pocketmine\event\entity\EntityRegainHealthEvent;
use pocketmine\event\player\PlayerRespawnEvent;
use pocketmine\item\Item;
use pocketmine\item\VanillaItems;
use pocketmine\math\Vector3;
use pocketmine\player\Player;
use pocketmine\Server;
use pocketmine\world\format\Chunk;
use pocketmine\world\Position;
use pocketmine\world\World;
use rayveeu\essentials\command\tool\PositionCommand;
use rayveeu\essentials\entity\custom\CustomEntityData;
use rayveeu\essentials\entity\custom\CustomEntityManager;
use rayveeu\essentials\event\player\PlayerDeathEvent;
use rayveeu\essentials\event\player\PlayerKillEvent;
use rayveeu\essentials\music\GenericSounds;
use rayveeu\essentials\player\Session;
use rayveeu\essentials\registry\ItemRegistry;
use rayveeu\essentials\util\Emoji;
use rayveeu\essentials\util\SpawnPosition;
use rayveeu\essentials\util\TitleFormat;
use rayveeu\partycube\minigame\Minigame;
use rayveeu\partycube\minigame\paintball\entity\PaintballEntity;
use rayveeu\partycube\minigame\paintball\item\PaintballGunItem;
use rayveeu\partycube\minigame\paintball\map\FactoryPaintballMap;
use rayveeu\partycube\PartyCube;
use rayveeu\partycube\util\ranking\HighestPointsRanking;
use rayveeu\partycube\util\ranking\Ranking;

class PaintballMinigame extends Minigame{
    private array $occupiedPositions = [];

    public function getName(): string{
        return "Paintball";
    }

    public function getMapPool(): array{
        return [
            new FactoryPaintballMap(),
        ];
    }

    public function getInitialRankingType(): Ranking{
        return new HighestPointsRanking();
    }

    public function getItem(): Item{
        return VanillaItems::IRON_HOE();
    }

    public function onEnable(): void{
        CustomEntityManager::registerCustomEntityData(new CustomEntityData("rayveeu:paintball"));

        ItemRegistry::register(new PaintballGunItem());
    }

    public function onStart(): void{
        foreach(PartyCube::getInstance()->getSessions() as $session) {
            $player = $session->getPlayer();
            PaintballGunItem::give($player);

            MinigamePlayerType::get($player)->getKills()->set(0);

            $player->setNameTagAlwaysVisible(false);
            $player->setNameTagVisible(false);

            $session->sendTitle(TitleFormat::BOTTOM_LEFT, Emoji::KILLS." 0");
        }
    }

    public function onStop(): void{
        foreach(Session::getAll() as $session) {
            $session->resetTitle(TitleFormat::CENTER);
            $session->resetTitle(TitleFormat::TOP_LEFT_2);
            $session->resetTitle(TitleFormat::TOP_LEFT_1);
            $session->resetTitle(TitleFormat::BOTTOM_LEFT);

            $player = $session->getPlayer();
            $player->setNameTagAlwaysVisible(true);
            $player->setNameTagVisible(true);
        }
    }

    public function initTimer(): void{
        $this->timer = new Countdown(90);
    }

    protected function rankInRest(): void{
        foreach(PartyCube::getInstance()->getSessions() as $session) {
            $player = $session->getPlayer();
            $this->ranking->getPoints($player)->set(MinigamePlayerType::get($player)->getKills()->get());
        }
    }

    public function getSpawnFor(Player $player): SpawnPosition{
        if(MinigamePlayerType::get($player)->isSpectator()) {
            return parent::getSpawnFor($player);
        }
        /** @var SpawnPosition[] $spawns */
        $spawns = $this->getMap()->getSpawnPositions();
        shuffle($spawns);

        $position = null;
        while($position === null) {
            $spawn = array_shift($spawns);
            if((count($spawns) > 1) && $this->isEnemyNearby($player, $spawn)) {
                continue;
            }
            $position = $spawn;
        }
        return $position;
    }

    private function isEnemyNearby(Player $player, SpawnPosition $position, int $radius = 8): bool {
        $minX = ((int)floor($position->x - $radius)) >> Chunk::COORD_BIT_SIZE;
        $maxX = ((int)floor($position->x + $radius)) >> Chunk::COORD_BIT_SIZE;
        $minZ = ((int)floor($position->z - $radius)) >> Chunk::COORD_BIT_SIZE;
        $maxZ = ((int)floor($position->z + $radius)) >> Chunk::COORD_BIT_SIZE;

        $radius = $radius ** 2;

        $world = $player->getWorld();

        for($x = $minX; $x <= $maxX; ++$x){
            for($z = $minZ; $z <= $maxZ; ++$z){
                if(!$world->isChunkLoaded($x, $z)){
                    continue;
                }
                foreach($world->getChunkEntities($x, $z) as $entity){
                    if(!$entity instanceof Player || $entity->getId() === $player->getId() || MinigamePlayerType::get($entity)->isSpectator()) {
                        continue;
                    }
                    $distance = $entity->getPosition()->distanceSquared($position);
                    if($distance < $radius){
                        return true;
                    }
                }
            }
        }
        return false;
    }

    public function onEntityDamage(EntityDamageEvent $event): void{
        if($event->getCause() === EntityDamageEvent::CAUSE_PROJECTILE) {
            $event->uncancel();
        } else {
            $event->cancel();
        }
    }

    public function onPlayerDeath(PlayerDeathEvent $event): void{
        $event->setKeepInventory(true);
    }

    public function onPlayerKill(PlayerKillEvent $event): void{
        $killer = $event->getKiller();

        MinigamePlayerType::get($killer)->getKills()->add();

        $killer->setHealth($killer->getMaxHealth());

        GenericSounds::kill($killer);
        Session::getNullSafe($killer)->sendTitle(TitleFormat::TOP_LEFT_1, "title.killed_player", [
            "player" => Session::getNullSafe($event->getPlayer())->getDisplayName()
        ], 50, null, true);
        Session::getNullSafe($killer)->sendTitle(TitleFormat::BOTTOM_LEFT, Emoji::KILLS." ".MinigamePlayerType::get($killer)->getKills()->get());

        Session::getNullSafe($event->getPlayer())->sendTitle(TitleFormat::TOP_LEFT_2, "title.killed_by_player", [
            "player" => Session::getNullSafe($killer)->getDisplayName()
        ], 50, null, true);
    }

    public function onPlayerRespawn(PlayerRespawnEvent $event): void{
        $player = $event->getPlayer();
        $event->setRespawnPosition($this->getSpawnFor($player)->asLocation($this->map->getWorld()));
    }

    public function onEntityRegainHealth(EntityRegainHealthEvent $event): void{
        $event->cancel();
    }
}