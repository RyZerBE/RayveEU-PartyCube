<?php

declare(strict_types=1);

namespace rayveeu\partycube\minigame\paintball\entity;

use minigame\player\MinigamePlayerType;
use pocketmine\block\Block;
use pocketmine\entity\Entity;
use pocketmine\entity\EntitySizeInfo;
use pocketmine\entity\projectile\Projectile;
use pocketmine\event\entity\EntityDamageByEntityEvent;
use pocketmine\event\entity\EntityDamageEvent;
use pocketmine\math\RayTraceResult;
use pocketmine\math\Vector3;
use pocketmine\player\Player;
use pocketmine\world\particle\SmokeParticle;
use rayveeu\essentials\music\GenericSounds;

class PaintballEntity extends Projectile{
    private Vector3 $directionVector;

    private Vector3 $origin;

    public function __construct(Player $player){
        $location = $player->getLocation();
        $location->y += 1.6;
        parent::__construct($location, $player);

        $this->origin = $location->asVector3();

        $this->directionVector = $player->getDirectionVector()->multiply(4);

        $this->setScale(0.25);
        $this->spawnToAll();
    }

    public function canCollideWith(Entity $entity): bool{
        if($entity instanceof Player && MinigamePlayerType::get($entity)->isSpectator()) {
            return false;
        }
        return parent::canCollideWith($entity);
    }

    protected function getInitialSizeInfo(): EntitySizeInfo{
        return new EntitySizeInfo(0.3, 0.3);
    }

    protected function getInitialDragMultiplier(): float{
        return 0.0;
    }

    protected function getInitialGravity(): float{
        return 0.0;
    }

    public static function getNetworkTypeId(): string{
        return "rayveeu:paintball";
    }

    public function onUpdate(int $currentTick): bool{
        if($this->origin->distanceSquared($this->location) > 24 ** 2) {
            $this->flagForDespawn();
            return true;
        }
        $this->motion = $this->directionVector;
        parent::onUpdate($currentTick);
        return true;
    }

    public function getResultDamage(): int{
        return 10;
    }

    protected function onHitEntity(Entity $entityHit, RayTraceResult $hitResult): void{
        if($entityHit instanceof Player) {
            $entityHit->attack(new EntityDamageByEntityEvent($this, $entityHit, EntityDamageEvent::CAUSE_PROJECTILE, 99999, [], 0));
        }

        $this->flagForDespawn();
    }

    protected function onHitBlock(Block $blockHit, RayTraceResult $hitResult): void{
        $this->flagForDespawn();

        $world = $this->getWorld();
        $particle = new SmokeParticle();
        for($i = 0; $i <= 6; $i++) {
            $world->addParticle($this->location->add(random_int(-5, 5) / 10, random_int(-5, 5) / 10, random_int(-5, 5) / 10), $particle);
        }
    }

    public function canSaveWithChunk(): bool{
        return false;
    }
}