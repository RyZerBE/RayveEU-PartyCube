<?php

declare(strict_types=1);

namespace rayveeu\partycube\minigame\paintball\item;

use minigame\player\MinigamePlayerType;
use pocketmine\item\Item;
use pocketmine\item\VanillaItems;
use pocketmine\player\Player;
use rayveeu\essentials\item\modified\action\HeldItemAction;
use rayveeu\essentials\item\modified\action\InteractEntityAction;
use rayveeu\essentials\item\modified\action\InteractItemAction;
use rayveeu\essentials\item\modified\action\ItemAction;
use rayveeu\essentials\item\modified\action\TickAction;
use rayveeu\essentials\item\modified\action\UnheldItemAction;
use rayveeu\essentials\item\modified\ModifiedItem;
use rayveeu\essentials\music\GenericSounds;
use rayveeu\essentials\player\Session;
use rayveeu\essentials\util\TitleFormat;
use rayveeu\partycube\minigame\paintball\entity\PaintballEntity;

class PaintballGunItem extends ModifiedItem{
    protected function getInitialItem(): Item{
        return VanillaItems::IRON_HOE();
    }

    public function getCustomName(Player $player): ?string{
        return Session::getNullSafe($player)->translate("item.paintball_gun");
    }

    public function interact(InteractItemAction $action): ItemAction{
        new PaintballEntity($action->getPlayer());
        GenericSounds::paintball_shoot($action->getPlayer());
        return $action->resetCooldown(5);
    }

    public function interactEntity(InteractEntityAction $action): ItemAction{
        new PaintballEntity($action->getPlayer());
        GenericSounds::paintball_shoot($action->getPlayer());
        return $action;
    }

    public function held(HeldItemAction $action): ItemAction{
        if($action->getSession()->usesTouchScreen()) {
            $action->getSession()->sendTitle(TitleFormat::CENTER, "§l§f+");
        }
        return $action;
    }

    public function unheld(UnheldItemAction $action): ItemAction{
        $action->getSession()->resetTitle(TitleFormat::CENTER);
        return $action;
    }
}