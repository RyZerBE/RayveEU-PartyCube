<?php

declare(strict_types=1);

namespace rayveeu\partycube\minigame\paintball\map;

use pocketmine\math\AxisAlignedBB;
use rayveeu\essentials\util\math\Math;
use rayveeu\essentials\util\SpawnPosition;

class FactoryPaintballMap extends PaintballMap{
    private array $spawnAreas;
    private array $spawnPositions;

    public function getLevelName(): string{
        return "Paintball-1";
    }

    public function getSpawn(): SpawnPosition{
        return new SpawnPosition(0.5, 24.1, -25, 180);
    }

    public function getCredits(): array{
        return ["Matze998"];
    }

    public function getDisplayName(): string{
        return "Factory";
    }

    public function getSpawnPositions(): array {
        return $this->spawnPositions ??= [
            new SpawnPosition(6.5, 24.5, -24.5, 180),
            new SpawnPosition(-4.5, 24.5, -26.5, 180),
            new SpawnPosition(-16.5, 28.5, -41.5, 270),
            new SpawnPosition(-24.5, 24.5, -49.5, 315),
            new SpawnPosition(0.5, 24.5, -51.5, 0),
            new SpawnPosition(27.5, 24.5, -50.5, 45),
            new SpawnPosition(27.5, 24.5, -23.5, 135),
            new SpawnPosition(-28.5, 24.5, -25.5, 225),
            new SpawnPosition(-24.5, 25.5, -15.5, 315),
            new SpawnPosition(-12.5, 30.5, -4.5, 315),
            new SpawnPosition(-11.5, 30.5, 2.5, 270),
            new SpawnPosition(-20.5, 30.5, 2.5, 360),
            new SpawnPosition(-5.5, 30.5, 8.5, 315),
            new SpawnPosition(5.5, 30.5, 10.5, 0),
            new SpawnPosition(18.5, 30.5, 19.5, 225),
            new SpawnPosition(22.5, 30.5, 16.5, 180),
            new SpawnPosition(14.5, 30.5, 9.5, 135),
            new SpawnPosition(18.5, 30.5, -0.5, 180),
            new SpawnPosition(15.5, 30.5, -14.5, 360),
            new SpawnPosition(5.5, 30.5, -14.5, 0),
            new SpawnPosition(0.5, 25.5, -15.5, 360),
            new SpawnPosition(25.5, 25.5, -16.5, 45),
            new SpawnPosition(0.5, 25.5, 1.5, 180),
            new SpawnPosition(-1.5, 28.5, 19.5, 180),
            new SpawnPosition(8.5, 28.5, 19.5, 180),
            new SpawnPosition(5.5, 25.5, 10.5, 90),
            new SpawnPosition(-24.5, 28.5, 21.5, 225),
            new SpawnPosition(-6.5, 28.5, 18.5, 180),
            new SpawnPosition(-11.5, 25.5, 21.5, 270),
            new SpawnPosition(-24.5, 25.5, 14.5, 180),
            new SpawnPosition(18.5, 25.5, 5.5, 360),
            new SpawnPosition(21.5, 28.5, -4.5, 180),
        ];
    }
}