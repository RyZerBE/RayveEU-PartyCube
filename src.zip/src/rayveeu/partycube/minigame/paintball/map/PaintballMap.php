<?php

declare(strict_types=1);

namespace rayveeu\partycube\minigame\paintball\map;

use minigame\map\StoredMap;
use rayveeu\essentials\util\SpawnPosition;

abstract class PaintballMap extends StoredMap{
    /**
     * @return SpawnPosition[]
     */
    abstract public function getSpawnPositions(): array;
}