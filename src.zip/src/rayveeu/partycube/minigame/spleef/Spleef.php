<?php

declare(strict_types=1);

namespace rayveeu\partycube\minigame\spleef;

use minigame\map\MapManager;
use minigame\player\MinigamePlayerType;
use pocketmine\block\VanillaBlocks;
use pocketmine\event\block\BlockBreakEvent;
use pocketmine\event\entity\EntityDamageEvent;
use pocketmine\event\entity\ProjectileHitBlockEvent;
use pocketmine\event\inventory\InventoryTransactionEvent;
use pocketmine\event\player\PlayerItemUseEvent;
use pocketmine\event\player\PlayerMoveEvent;
use pocketmine\item\enchantment\EnchantmentInstance;
use pocketmine\item\enchantment\VanillaEnchantments;
use pocketmine\item\Item;
use pocketmine\item\VanillaItems;
use pocketmine\player\GameMode;
use pocketmine\player\Player;
use pocketmine\Server;
use pocketmine\world\particle\BlockBreakParticle;
use pocketmine\world\particle\HappyVillagerParticle;
use rayveeu\essentials\player\Session;
use rayveeu\essentials\util\Countable;
use rayveeu\partycube\minigame\Minigame;
use rayveeu\partycube\minigame\spleef\map\SnowlandSpleefMap;
use rayveeu\partycube\PartyCube;
use rayveeu\partycube\util\ranking\HighestPointsRanking;
use rayveeu\partycube\util\ranking\LowestPointsRanking;
use rayveeu\partycube\util\ranking\Ranking;

class Spleef extends Minigame{
    public const SNOWBALL_CACHE_ENTRY = "spleef_snowballs";
    public const SNOWBALL_MULTIPLIER_CACHE_ENTRY = "spleef_snowballs_multiplier";

    public function getName(): string{
        return "Spleef";
    }

    public function getMapPool(): array{
        return [
            new SnowlandSpleefMap(),
        ];
    }

    public function getInitialRankingType(): Ranking{
        return new HighestPointsRanking();
    }

    public function getItem(): Item{
        return VanillaItems::NETHERITE_SHOVEL();
    }

    public function onStart(): void{
        foreach(PartyCube::getInstance()->getSessions() as $session) {
            $session->reset();
            $player = $session->getPlayer();

            $player->setGamemode(GameMode::SURVIVAL());

            $player->getInventory()->addItem(VanillaItems::NETHERITE_SHOVEL()->addEnchantment(new EnchantmentInstance(VanillaEnchantments::EFFICIENCY(), 10))->setUnbreakable());

            $this->getSnowballs($player)->set(0);
        }
    }

    protected function rankInRest(): void{
        foreach(PartyCube::getInstance()->getSessions() as $session) {
            $this->ranking->getPoints($session->getPlayer())->set(999999);
        }
    }

    private function getSnowballs(Player $player): Countable {
        $cache = Session::getNullSafe($player)->getCache();
        if(!$cache->exists(self::SNOWBALL_CACHE_ENTRY)) {
            $cache->set(self::SNOWBALL_CACHE_ENTRY, new Countable());
        }
        return $cache->get(self::SNOWBALL_CACHE_ENTRY);
    }

    private function updateSnowballs(Player $player): void {
        $amount = $this->getSnowballs($player)->get();
        if($amount <= 0) {
            $player->getInventory()->clear(8);
            return;
        }
        $item = VanillaItems::SNOWBALL();
        $player->getInventory()->setItem(8, $item->setCount(min(100, $amount))->setCustomName("§r§fSnowball ".$amount."x"));
    }

    public function onBlockBreak(BlockBreakEvent $event): void{
        $block = $event->getBlock();
        if($block->isSameState(VanillaBlocks::SNOW())) {
            $player = $event->getPlayer();
            $session = Session::getNullSafe($player);
            $cache = $session->getCache();

            $amount = 1;
            // Lucky break
            if(random_int(0, 100) <= 0) {
                $session->playSound("mob.allay.item_given");
                $amount = 8;

                $position = $block->getPosition();
                $world = $position->getWorld();
                $particle = new HappyVillagerParticle();
                for($i = 0; $i <= 10; $i++) {
                    $world->addParticle($position->add(random_int(0, 10) / 10, random_int(6, 13) / 10, random_int(0, 10) / 10), $particle);
                }
            }

            $this->getSnowballs($player)->add((int)ceil($amount * $cache->get(self::SNOWBALL_MULTIPLIER_CACHE_ENTRY, 1)));
            $this->updateSnowballs($player);

            $event->setDrops([]);
            return;
        }
        $event->cancel();
    }

    public function onPlayerMove(PlayerMoveEvent $event): void{
        $player = $event->getPlayer();
        if(MinigamePlayerType::get($player)->isSpectator()) {
            return;
        }
        if($event->getTo()->getY() <= MapManager::getCurrentMapNullSafe()->getDeathHeight()) {
            $session = Session::getNullSafe($player);

            $session->reset();
            $this->getMap()->teleport($player);

            $this->getRanking()->getPoints($player)->set(Server::getInstance()->getTick());
            MinigamePlayerType::get($player)->setSpectator(true);

            PartyCube::getInstance()->broadcastMessage("message.player_died", [
                "player" => $session->getDisplayName()
            ]);
        }
    }

    public function onProjectileHitBlock(ProjectileHitBlockEvent $event): void{
        $block = $event->getBlockHit();
        if($block->isSameState(VanillaBlocks::SNOW())) {
            $position = $block->getPosition();
            $world = $position->getWorld();
            $world->addParticle($position, new BlockBreakParticle($block));
            $world->setBlock($position, VanillaBlocks::AIR());
        }
    }

    public function onEntityDamage(EntityDamageEvent $event): void{
        if($event->getCause() === EntityDamageEvent::CAUSE_PROJECTILE) {
            $event->setBaseDamage(0);
            $event->uncancel();
            return;
        }
        parent::onEntityDamage($event);
    }

    public function onPlayerItemUse(PlayerItemUseEvent $event): void{
        $item = $event->getItem();
        if($item->equals(VanillaItems::SNOWBALL(), false, false)) {
            $player = $event->getPlayer();
            $snowballs = $this->getSnowballs($player)->subtract();
            $this->updateSnowballs($player);

            $player->sendPopup("§r§fSnowball ".$snowballs->get()."x");
        }
    }

    public function onInventoryTransaction(InventoryTransactionEvent $event): void{
        $event->cancel();
    }
}