<?php

declare(strict_types=1);

namespace rayveeu\partycube\minigame\spleef\map;

use rayveeu\essentials\util\SpawnPosition;

class SnowlandSpleefMap extends SpleefMap{
    public function getLevelName(): string{
        return "Spleef-1";
    }

    public function getSpawn(): SpawnPosition{
        return new SpawnPosition(0.5, 16, 0.5, 0);
    }

    public function getCredits(): array{
        return ["zueinfxch"];
    }

    public function getDisplayName(): string{
        return "Snowland";
    }

    public function getDeathHeight(): int{
        return 11;
    }
}