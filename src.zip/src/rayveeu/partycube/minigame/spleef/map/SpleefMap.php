<?php

declare(strict_types=1);

namespace rayveeu\partycube\minigame\spleef\map;

use minigame\map\StoredMap;

abstract class SpleefMap extends StoredMap{
    abstract public function getDeathHeight(): int;
}