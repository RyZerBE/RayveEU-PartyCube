<?php

declare(strict_types=1);

namespace rayveeu\partycube\minigame\tntrun;

use minigame\map\Map;
use minigame\player\MinigamePlayerType;
use pocketmine\block\PressurePlate;
use pocketmine\block\Sand;
use pocketmine\block\StonePressurePlate;
use pocketmine\block\VanillaBlocks;
use pocketmine\block\WeightedPressurePlate;
use pocketmine\block\WeightedPressurePlateHeavy;
use pocketmine\entity\Location;
use pocketmine\entity\object\FallingBlock;
use pocketmine\event\block\BlockUpdateEvent;
use pocketmine\event\entity\EntityBlockChangeEvent;
use pocketmine\event\player\PlayerMoveEvent;
use pocketmine\item\Item;
use pocketmine\math\Axis;
use pocketmine\math\Facing;
use pocketmine\math\Vector3;
use pocketmine\Server;
use pocketmine\world\particle\BlockBreakParticle;
use pocketmine\world\particle\ExplodeParticle;
use rayveeu\essentials\player\Session;
use rayveeu\partycube\minigame\Minigame;
use rayveeu\partycube\minigame\tntrun\map\StoneCircleTNTRunMap;
use rayveeu\partycube\PartyCube;
use rayveeu\partycube\util\ranking\HighestPointsRanking;
use rayveeu\partycube\util\ranking\LowestPointsRanking;
use rayveeu\partycube\util\ranking\Ranking;

class TNTRunMinigame extends Minigame{
    private array $blockQueue = [];

    public function getName(): string{
        return "TNTRun";
    }

    public function getMapPool(): array{
        return [
            new StoneCircleTNTRunMap(),
        ];
    }

    public function getInitialRankingType(): Ranking{
        return new HighestPointsRanking();
    }

    public function getItem(): Item{
        return VanillaBlocks::TNT()->asItem();
    }

    public function tick(int $tick): void{
        $world = $this->map->getWorld();
        /** @var Vector3 $vector3 */
        foreach(($this->blockQueue[$tick] ?? []) as $vector3) {
            for($step = 0; $step <= 2; $step++) {
                $pos = $vector3->down($step);

                $fall = new FallingBlock(Location::fromObject($pos->add(0.5, 0, 0.5), $world), $world?->getBlock($pos));
                $fall->spawnToAll();

                $world?->setBlock($pos, VanillaBlocks::AIR());
            }
        }
        unset($this->blockQueue[$tick]);
    }

    public function onStart(): void{
        foreach(PartyCube::getInstance()->getSessions() as $session) {
            $location = $session->getPlayer()->getLocation();
            $event = new PlayerMoveEvent($session->getPlayer(), $location, $location);
            $event->call();
        }
    }

    public function onStop(): void{
        foreach($this->map->getWorld()->getEntities() as $entity) {
            if($entity instanceof FallingBlock) {
                $entity->flagForDespawn();
            }
        }
    }

    public function onPlayerMove(PlayerMoveEvent $event): void{
        $player = $event->getPlayer();
        if(MinigamePlayerType::get($player)->isSpectator()) {
            return;
        }
        $to = $event->getTo();
        if($player->isOnGround()) {
            $world = $player->getWorld();
            $tick = Server::getInstance()->getTick();

            $session = Session::getNullSafe($player);

            $collision = false;
            foreach($world->getCollisionBlocks($player->getBoundingBox()->expandedCopy(0, 2, 0)) as $block) {
                $side = $block->getSide(Facing::UP);
                if($side instanceof StonePressurePlate) {
                    $collision = true;

                    $pos = $side->getPosition();
                    $this->blockQueue[$tick + 5][] = $pos;
                    $world->setBlock($pos, VanillaBlocks::SPRUCE_PRESSURE_PLATE());
                }
            }
            if($collision && !$session->hasCooldown("click_on.stone_pressure_plate")) {
                $session->playSound("click_on.stone_pressure_plate");
                $session->resetCooldown("click_on.stone_pressure_plate", 5);
            }
        }

        if($to->getY() <= $this->map->getDeathHeight()) {
            $this->ranking->getPoints($player)->set(Server::getInstance()->getTick());

            $this->getSpawnFor($player)->teleport($player);
            MinigamePlayerType::get($player)->setSpectator(true);

            PartyCube::getInstance()->broadcastMessage("message.player_died", [
                "player" => Session::getNullSafe($player)->getDisplayName()
            ]);

            $player->extinguish();
        }
    }

    public function onEntityBlockChange(EntityBlockChangeEvent $event): void{
        $event->getEntity()?->flagForDespawn();
        $event->cancel();
    }
}