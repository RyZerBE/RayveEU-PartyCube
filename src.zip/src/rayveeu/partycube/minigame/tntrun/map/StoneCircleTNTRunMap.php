<?php

declare(strict_types=1);

namespace rayveeu\partycube\minigame\tntrun\map;

use rayveeu\essentials\util\SpawnPosition;

class StoneCircleTNTRunMap extends TNTRunMap{
    public function getLevelName(): string{
        return "TNTRun-1";
    }

    public function getSpawn(): SpawnPosition{
        return new SpawnPosition(0.5, 19.1, 0.5, 0);
    }

    public function getCredits(): array{
        return ["zueinfxch"];
    }

    public function getDisplayName(): string{
        return "Stone Circle";
    }

    public function getDeathHeight(): int{
        return 15;
    }
}