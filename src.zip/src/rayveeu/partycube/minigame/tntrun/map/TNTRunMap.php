<?php

declare(strict_types=1);

namespace rayveeu\partycube\minigame\tntrun\map;

use minigame\map\StoredMap;

abstract class TNTRunMap extends StoredMap{
    abstract public function getDeathHeight(): int;
}