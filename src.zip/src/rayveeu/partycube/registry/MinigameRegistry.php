<?php

declare(strict_types=1);

namespace rayveeu\partycube\registry;

use rayveeu\partycube\minigame\escapethehylope\EscapeTheHylope;
use rayveeu\partycube\minigame\escapethelava\EscapeTheLava;
use rayveeu\partycube\minigame\findthebutton\FindTheButtonMinigame;
use rayveeu\partycube\minigame\getdown\GetDown;
use rayveeu\partycube\minigame\getit\GetIt;
use rayveeu\partycube\minigame\jumpandrun\JumpAndRun;
use rayveeu\partycube\minigame\minefield\MinefieldMinigame;
use rayveeu\partycube\minigame\MinigameManager;
use rayveeu\partycube\minigame\mlgrun\MLGRun;
use rayveeu\partycube\minigame\paintball\PaintballMinigame;
use rayveeu\partycube\minigame\spleef\Spleef;
use rayveeu\partycube\minigame\tntrun\TNTRunMinigame;

class MinigameRegistry{
    public function __construct(){
        MinigameManager::register(new Spleef());
        MinigameManager::register(new GetIt());
        MinigameManager::register(new EscapeTheHylope());
        MinigameManager::register(new MLGRun());
        MinigameManager::register(new GetDown());
        MinigameManager::register(new JumpAndRun());
        MinigameManager::register(new EscapeTheLava());
        MinigameManager::register(new FindTheButtonMinigame());
        MinigameManager::register(new MinefieldMinigame());
        MinigameManager::register(new PaintballMinigame());
        MinigameManager::register(new TNTRunMinigame());
    }
}