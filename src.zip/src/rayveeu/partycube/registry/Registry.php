<?php

declare(strict_types=1);

namespace rayveeu\partycube\registry;

use rayveeu\essentials\registry\BaseRegistry;

class Registry extends BaseRegistry{
    public static function init(): void{
        new MinigameRegistry();
    }
}