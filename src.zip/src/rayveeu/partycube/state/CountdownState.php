<?php

declare(strict_types=1);

namespace rayveeu\partycube\state;

use minigame\map\Map;
use minigame\map\MapManager;
use minigame\player\MinigamePlayerType;
use minigame\template\state\CountdownTemplateState;
use pocketmine\event\entity\EntityDamageEvent;
use pocketmine\player\Player;
use pocketmine\world\Position;
use rayveeu\essentials\event\player\PlayerInitializeEvent;
use rayveeu\essentials\player\PlayerSession;
use rayveeu\essentials\player\Session;
use rayveeu\essentials\util\Queue;
use rayveeu\partycube\map\IngameLobbyMap;
use rayveeu\partycube\minigame\MinigameManager;
use rayveeu\partycube\PartyCube;

class CountdownState extends CountdownTemplateState{
    protected function loadGameMap(): Map{
        if(PartyCube::$showcaseGame !== null) {
            MinigameManager::setCurrent(MinigameManager::get(PartyCube::$showcaseGame));
            return MinigameManager::getCurrentNullSafe()->loadMap();
        }
        $map = new IngameLobbyMap();
        MapManager::register($map);
        $map->load(fn() => null);
        return $map;
    }

    protected function initGameTeleport(): void{
        if(PartyCube::$showcaseGame === null) {
            $this->queue = new Queue(function(string $xuid): void {
                $session = Session::get($xuid);
                if($session === null) {
                    return;
                }
                MapManager::getCurrentMapNullSafe()->teleport($session->getPlayer());
                $session->reset();
            }, array_map(function(PlayerSession $session): string {
                return $session->getXboxId();
            }, Session::getAll()));
        }
    }

    public function onPlayerInitialize(PlayerInitializeEvent $event): void{
        $player = $event->getPlayer();
        $type = MinigamePlayerType::get($player);
        if($this->countdown->get() <= 0) {
            $type->setSpectator(true);
        }
        MapManager::getCurrentMapNullSafe()->teleport($player);
    }

    public function giveItems(Player $player): void{
    }
}