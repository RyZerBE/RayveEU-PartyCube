<?php

declare(strict_types=1);

namespace rayveeu\partycube\state;

use minigame\template\state\IngameTemplateState;
use pocketmine\event\player\PlayerQuitEvent;
use pocketmine\player\Player;
use pocketmine\Server;
use rayveeu\partycube\minigame\MinigameManager;
use rayveeu\partycube\PartyCube;
use rayveeu\partycube\state\phase\InitializeMinigamePhase;
use rayveeu\partycube\state\phase\MinigameEvaluationPhase;
use rayveeu\partycube\state\phase\MinigameRunPhase;
use rayveeu\partycube\state\phase\MinigameStartPhase;
use rayveeu\partycube\state\phase\Phase;

class IngameState extends IngameTemplateState{
    /** @var Phase[] */
    private array $phases = [];
    private Phase $currentPhase;

    protected function registerPhase(Phase $phase): void {
        $this->phases[$phase::getId()] = $phase;
        $phase->onLoad();
    }

    public function onLoad(): void{
        $this->registerPhase(new InitializeMinigamePhase());
        $this->registerPhase(new MinigameStartPhase());
        $this->registerPhase(new MinigameRunPhase());
        $this->registerPhase(new MinigameEvaluationPhase());
    }

    public function onEnable(): void{
        parent::onEnable();
        foreach(PartyCube::getInstance()->getSessions() as $session) {
            foreach(PartyCube::getInstance()->getSessions() as $playerSession) {
                $session->getPlayer()->showPlayer($playerSession->getPlayer());
            }
        }
        if(!isset($this->currentPhase)) {
            if(PartyCube::$showcaseGame !== null) {
                $this->setPhase(MinigameStartPhase::getId());
            } else {
                $this->setPhase(InitializeMinigamePhase::getId());
            }
        }
    }

    public function onPlayerQuit(PlayerQuitEvent $event): void{
        parent::onPlayerQuit($event);
        if(count(PartyCube::getInstance()->getSessions()) <= 2) {
            MinigameManager::getCurrent()?->stop();
        }
    }

    public function setPhase(Phase|int $phase): void{
        if(!$phase instanceof Phase) {
            $phase = $this->phases[$phase];
        }
        if(isset($this->currentPhase)) {
            $this->currentPhase->onDisable();
        }
        $this->currentPhase = $phase;
        $this->currentPhase->onEnable();
    }

    public function getPhase(): Phase{
        return $this->currentPhase;
    }

    public function tick(int $tick): void{
        $this->currentPhase->tick($tick);
    }

    protected function trySaveInventory(Player $player, bool $force = false): bool{
        return true;
    }
}