<?php

declare(strict_types=1);

namespace rayveeu\partycube\state;

use minigame\map\Map;
use minigame\map\MapManager;
use minigame\player\MinigamePlayerType;
use minigame\template\state\RestartTemplateState;
use pocketmine\player\GameMode;
use pocketmine\Server;
use rayveeu\essentials\player\Session;
use rayveeu\essentials\util\ListGenerator;
use rayveeu\essentials\util\TitleFormat;
use rayveeu\partycube\PartyCube;
use rayveeu\partycube\util\ranking\Ranking;

class RestartState extends RestartTemplateState{
    public function onEnable(): void{
        /** @var Ranking $ranking */
        $ranking = PartyCube::getInstance()->getCurrentRanking();

        $placements = $ranking->getPlacements();
        $first = ListGenerator::createNameList($placements[1] ?? []);
        $second = ListGenerator::createNameList($placements[2] ?? []);
        $third = ListGenerator::createNameList($placements[3] ?? []);

        foreach(Session::getAll() as $session) {
            $player = $session->getPlayer();
            $player->setGamemode(GameMode::ADVENTURE());
            $session->reset();

            //TODO: Items

            if(PartyCube::$showcaseGame === null) {
                if(MinigamePlayerType::get($player)->isSpectator()) {
                    $session->sendMessage("message.partycube_spectator_ranking", [
                        "first" => $first,
                        "second" => $second,
                        "third" => $third,
                    ]);
                } else {
                    $placement = $ranking->getPlacement($player);
                    $session->sendMessage("message.partycube_ranking", [
                        "first" => $first,
                        "second" => $second,
                        "third" => $third,
                        "placement" => $placement
                    ]);
                }
            }

            $session->sendTitle(TitleFormat::CENTER_RAISED, "title.partycube_winner", [
                "player" => $first
            ], 100);
        }


        parent::onEnable();
    }

    public function getLobbyMap(): Map{
        return MapManager::getMap(Server::getInstance()->getWorldManager()->getDefaultWorld());
    }
}