<?php

declare(strict_types=1);

namespace rayveeu\partycube\state;

use minigame\map\MapManager;
use minigame\template\state\WaitingTemplateState;
use minigame\util\PluginInfo;
use pocketmine\event\entity\EntityDamageEvent;
use pocketmine\player\Player;
use rayveeu\essentials\event\player\PlayerInitializeEvent;
use rayveeu\partycube\PartyCube;

class WaitingState extends WaitingTemplateState{
    public function onPlayerInitialize(PlayerInitializeEvent $event): void{
        $player = $event->getPlayer();
        MapManager::getCurrentMapNullSafe()->teleport($player);

        if($player->getName() === "zuWxld") {
            PartyCube::getInstance()->setForceStart(true);
        }
    }

    public function giveItems(Player $player): void{
    }
}