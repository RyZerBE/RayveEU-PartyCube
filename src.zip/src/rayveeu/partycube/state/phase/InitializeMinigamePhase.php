<?php

declare(strict_types=1);

namespace rayveeu\partycube\state\phase;

use minigame\map\MapManager;
use minigame\player\MinigamePlayerType;
use minigame\util\Countdown;
use pocketmine\event\entity\EntityDamageEvent;
use pocketmine\event\player\PlayerMoveEvent;
use pocketmine\Server;
use rayveeu\essentials\animation\Animation;
use rayveeu\essentials\util\TitleFormat;
use rayveeu\partycube\animation\BroadcastMinigameAnimation;
use rayveeu\partycube\map\IngameLobbyMap;
use rayveeu\partycube\minigame\MinigameManager;
use rayveeu\partycube\PartyCube;

class InitializeMinigamePhase extends Phase{
    private Countdown $countdown;
    private Animation $animation;

    public function onLoad(): void{
        $this->countdown = new Countdown(10);
        $this->animation = new BroadcastMinigameAnimation();
    }

    public function onEnable(): void{
        MinigameManager::getCurrent()?->getMap()->delete(fn() => null);
        MapManager::setCurrentMap(MapManager::getMap(IngameLobbyMap::NAME));

        $this->countdown->start();

        foreach(PartyCube::getInstance()->getSessions() as $session) {
            $session->sendTitle(TitleFormat::BOTTOM_LEFT, "title.your_points", [
                "points" => MinigamePlayerType::get($session->getPlayer())->getPoints()->get()
            ]);
        }
    }

    public static function getId(): int{
        return 1;
    }

    public function tick(int $tick): void{
        $timer = $this->countdown->get();
        if($timer <= 0) {
            if($timer === 0 && !$this->animation->isRunning()) {
                MinigameManager::initNext();

                PartyCube::getInstance()->broadcastTitle(TitleFormat::TOP_LEFT_1, "");
                $this->animation->start(...Server::getInstance()->getOnlinePlayers());
            }
            if(!$this->animation->isRunning()) {
                if(!MinigameManager::getCurrentNullSafe()->isInitialized()) {
                    return;
                }
                MapManager::setCurrentMap(MinigameManager::getCurrentNullSafe()->getMap());
                PartyCube::getInstance()->getState()->setPhase(MinigameStartPhase::getId());
            }
            return;
        }

        if($tick % 10 === 0) {
            PartyCube::getInstance()->broadcastTitle(TitleFormat::TOP_LEFT_1, "title.next_minigame_countdown".($timer === 1 ? "_one" : ""), [
                "countdown" => $timer,
                "points" => str_repeat(".", (int)ceil(($tick % 61) / 20))
            ]);
        }
    }

    public function onEntityDamage(EntityDamageEvent $event): void{
        $event->cancel();
    }

    public function onPlayerMove(PlayerMoveEvent $event): void{
        if($event->getTo()->getY() <= 40) {
            MapManager::getCurrentMapNullSafe()->teleport($event->getPlayer());
        }
    }
}