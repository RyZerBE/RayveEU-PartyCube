<?php

declare(strict_types=1);

namespace rayveeu\partycube\state\phase;

use minigame\map\MapManager;
use minigame\player\MinigamePlayerType;
use minigame\player\PlayerCache;
use minigame\util\Countdown;
use pocketmine\event\entity\EntityDamageEvent;
use pocketmine\event\entity\EntityItemPickupEvent;
use pocketmine\event\player\PlayerDropItemEvent;
use pocketmine\player\GameMode;
use pocketmine\Server;
use rayveeu\essentials\player\PlayerSession;
use rayveeu\essentials\player\Session;
use rayveeu\essentials\util\ListGenerator;
use rayveeu\essentials\util\Queue;
use rayveeu\essentials\util\TitleFormat;
use rayveeu\partycube\map\IngameLobbyMap;
use rayveeu\partycube\minigame\MinigameManager;
use rayveeu\partycube\PartyCube;
use rayveeu\partycube\state\RestartState;

class MinigameEvaluationPhase extends Phase{
    private Countdown $countdown;
    private Queue $queue;

    private bool $restart = false;

    public static function getId(): int{
        return 4;
    }

    public function onLoad(): void{
        $this->countdown = new Countdown(6);
    }

    public function onEnable(): void{
        MinigameManager::$played++;

        // Reborn spectators
        foreach(PlayerCache::getPlayers() as $xboxId => $ignore) {
            $session = Session::get((string)$xboxId);
            if($session === null) {
                continue;
            }
            MinigamePlayerType::get($session->getPlayer())->setSpectator(false);
        }

        // Broadcast ranking
        $ranking = MinigameManager::getCurrentNullSafe()->getRanking();

        $placements = $ranking->getPlacements();
        $first = ListGenerator::createNameList($placements[1] ?? []);
        $second = ListGenerator::createNameList($placements[2] ?? []);
        $third = ListGenerator::createNameList($placements[3] ?? []);

        foreach(Session::getAll() as $session) {
            if(MinigamePlayerType::get($session->getPlayer())->isSpectator()) {
                $session->sendMessage("message.partycube_spectator_ranking", [
                    "first" => $first,
                    "second" => $second,
                    "third" => $third,
                ]);
            } else {
                $player = $session->getPlayer();
                $placement = $ranking->getPlacement($player);

                $session->sendMessage("message.partycube_ranking", [
                    "first" => $first,
                    "second" => $second,
                    "third" => $third,
                    "placement" => $placement
                ]);

                $session->getBossbar()->hide();
                $session->reset();
                $player->setGamemode(GameMode::ADVENTURE());
                $player->setAllowFlight(true);
                $player->setFlying(true);

                MinigamePlayerType::get($player)->getPoints()->add((match ($placement) {
                    1 => 3,
                    2 => 2,
                    3 => 1,
                    default => 0
                }) * (MinigameManager::$played === MinigameManager::MAX_MINIGAMES ? 2 : 1));

                if(PartyCube::$showcaseGame === null) {
                    $session->sendTitle(TitleFormat::BOTTOM_LEFT, "title.your_points", [
                        "points" => MinigamePlayerType::get($player)->getPoints()->get()
                    ]);
                }
            }
        }
        $this->countdown->start();
    }

    public function tick(int $tick): void{
        if($this->countdown->get() > 0) {
            return;
        }
        if($tick % 20 === 0 && $this->countdown->get() === 0) {
            if(PartyCube::$showcaseGame !== null || MinigameManager::$played >= MinigameManager::MAX_MINIGAMES || count(PartyCube::getInstance()->getSessions()) <= 1) {
                PartyCube::getInstance()->setState(RestartState::getId());
                return;
            }
            MapManager::setCurrentMap(MapManager::getMap(IngameLobbyMap::NAME));
            $this->queue = new Queue(function(string $xuid): void {
                $session = Session::get($xuid);
                if($session === null) {
                    return;
                }
                $player = $session->getPlayer();
                $player->setAllowFlight(false);
                $player->setFlying(false);
                $player->setGamemode(GameMode::ADVENTURE());
                MapManager::getCurrentMapNullSafe()->teleport($player);
            }, array_map(function(PlayerSession $session): string {
                return $session->getXboxId();
            }, Session::getAll()));
        }

        if($this->queue->isEmpty()) {
            PartyCube::getInstance()->getState()->setPhase(InitializeMinigamePhase::getId());
            return;
        }
        $this->queue->shiftHandle();
    }

    public function onEntityItemPickup(EntityItemPickupEvent $event): void{
        $event->cancel();
    }

    public function onEntityDamage(EntityDamageEvent $event): void{
        $event->cancel();
    }

    public function onPlayerDropItem(PlayerDropItemEvent $event): void{
        $event->cancel();
    }
}