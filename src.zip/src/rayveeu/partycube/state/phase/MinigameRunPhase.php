<?php

declare(strict_types=1);

namespace rayveeu\partycube\state\phase;

use minigame\map\MapManager;
use rayveeu\essentials\player\Session;
use rayveeu\essentials\util\Emoji;
use rayveeu\essentials\util\TitleFormat;
use rayveeu\partycube\minigame\MinigameManager;
use rayveeu\partycube\PartyCube;
use rayveeu\replaysystem\studio\ReplayStudio;

class MinigameRunPhase extends Phase{
    public static function getId(): int{
        return 3;
    }

    public function onDisable(): void{
        foreach(Session::getAll() as $session) {
            $session->resetTitle(TitleFormat::BOTTOM_RIGHT);
        }
    }

    public function tick(int $tick): void{
        $minigame = MinigameManager::getCurrentNullSafe();
        if($minigame->canStop() || !$minigame->isRunning()) {
            $minigame->stop();
            ReplayStudio::stopRecording(MapManager::getCurrentMapNullSafe()->getWorld());
            PartyCube::getInstance()->getState()->setPhase(MinigameEvaluationPhase::getId());
            return;
        }
        $minigame->tick($tick);
        if($tick % 20 === 0) {
            $time = $minigame->getTimer()->get();
            $string = Emoji::CLOCK." §r§f§r".((int)floor($time / 60)).":".($time % 60 < 10 ? "0".$time % 60 : $time % 60);
            foreach(Session::getAll() as $session) {
                $session->sendTitle(TitleFormat::BOTTOM_RIGHT, $string);
            }
        }
    }
}