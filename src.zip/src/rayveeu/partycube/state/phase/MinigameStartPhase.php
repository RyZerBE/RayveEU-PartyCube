<?php

declare(strict_types=1);

namespace rayveeu\partycube\state\phase;

use minigame\map\MapManager;
use minigame\player\PlayerCache;
use minigame\util\Countdown;
use pocketmine\event\entity\EntityDamageEvent;
use pocketmine\player\Player;
use pocketmine\Server;
use pocketmine\world\Position;
use rayveeu\essentials\player\Session;
use rayveeu\essentials\util\Queue;
use rayveeu\essentials\util\TitleFormat;
use rayveeu\partycube\minigame\MinigameManager;
use rayveeu\partycube\PartyCube;
use rayveeu\replaysystem\studio\ReplayStudio;

class MinigameStartPhase extends Phase{
    private Queue $queue;
    private Countdown $countdown;

    public static function getId(): int{
        return 2;
    }

    public function onLoad(): void{
        $this->countdown = new Countdown(8);
    }

    public function onEnable(): void{
        $this->queue = new Queue(function(string $xboxId): void {
            $session = Session::get($xboxId);
            if($session === null) {
                return;
            }
            $minigame = MinigameManager::getCurrentNullSafe();
            $player = $session->getPlayer();
            $spawn = $minigame->getSpawnFor($player);

            $player->teleport(Position::fromObject($spawn, $minigame->getMap()->getWorld()), $spawn->getYaw(), $spawn->getPitch());
            $player->setNoClientPredictions(false);
            $session->reset();

            $minigame->onQueuedPlayerTeleport($player);
        }, array_map(function(Player $player): string {
            return $player->getXuid();
        }, Server::getInstance()->getOnlinePlayers()));
        $this->countdown->reset();

        foreach(PartyCube::getInstance()->getSessions() as $session) {
            PlayerCache::add($session->getPlayer(), []);
        }
    }

    public function tick(int $tick): void{
        if(!$this->queue->isEmpty()) {
            $this->queue->shiftHandle();
            return;
        }
        $timer = $this->countdown->get();
        if($tick % 10 === 0 && $timer > 0) {
            PartyCube::getInstance()->broadcastTitle(TitleFormat::TOP_LEFT_1, "title.game_countdown".($timer === 1 ? "_one" : ""), [
                "countdown" => $timer,
                "points" => str_repeat(".", (int)ceil(($tick % 61) / 20))
            ], 20);
        }

        if(($tick % 20 === 0) && $timer === 0) {
            $plugin = PartyCube::getInstance();
            $plugin->getState()->setPhase(MinigameRunPhase::getId());
            $plugin->broadcastTitle(TitleFormat::CENTER_RAISED, "title.minigame_go", [], 60);

            foreach(PartyCube::getInstance()->getSessions() as $session) {
                $session->getPlayer()->removeCurrentWindow();
            }

            MinigameManager::getCurrentNullSafe()->start();
            MinigameManager::getCurrentNullSafe()->startReplay();
        }
    }

    public function onEntityDamage(EntityDamageEvent $event): void{
        $event->cancel();
    }
}