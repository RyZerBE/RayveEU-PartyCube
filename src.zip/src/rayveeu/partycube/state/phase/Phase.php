<?php

declare(strict_types=1);

namespace rayveeu\partycube\state\phase;

use minigame\util\HandlerListTrait;

abstract class Phase{
    use HandlerListTrait;

    public function tick(int $tick): void{}

    public function onLoad(): void{}

    public function onEnable(): void{}
    public function onDisable(): void{}

    abstract public static function getId(): int;
}