<?php

declare(strict_types=1);

namespace rayveeu\partycube\util;

use pocketmine\block\Block;
use pocketmine\block\RuntimeBlockStateRegistry;
use pocketmine\math\Vector3;
use pocketmine\scheduler\AsyncTask;
use pocketmine\world\format\Chunk;
use pocketmine\world\World;

abstract class AsyncGenerator extends AsyncTask{
    protected function getChunk(array &$chunks, int $x, int $z): Chunk {
        return $chunks[World::chunkHash($x, $z)] ??= new Chunk([], true);
    }

    protected function fill(Vector3 $pos1, Vector3 $pos2, array $blocks, array &$chunks): void {
        for($x = min($pos1->x, $pos2->x); $x <= max($pos1->x, $pos2->x); $x++){
            for($y = min($pos1->y, $pos2->y); $y <= max($pos1->y, $pos2->y); $y++){
                for($z = min($pos1->z, $pos2->z); $z <= max($pos1->z, $pos2->z); $z++){
                    $this->setBlock((int)$x, (int)$y, (int)$z, $blocks[array_rand($blocks)], $chunks);
                }
            }
        }
    }

    protected function setBlock(int $x, int $y, int $z, Block $block, array &$chunks): void {
        $this->getChunk($chunks, $x >> 4, $z >> 4)->setBlockStateId($x % 16, $y, $z % 16, $block->getStateId());
    }

    protected function getBlock(int $x, int $y, int $z, array $chunks): Block {
        return RuntimeBlockStateRegistry::getInstance()->fromStateId($this->getChunk($chunks, $x >> 4, $z >> 4)->getBlockStateId($x, $y, $z));
    }
}