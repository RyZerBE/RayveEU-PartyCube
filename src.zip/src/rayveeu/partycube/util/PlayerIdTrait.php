<?php

declare(strict_types=1);

namespace rayveeu\partycube\util;

use pocketmine\player\Player;

trait PlayerIdTrait{
    private int $id = 0;
    private array $ids = [];

    public function getId(Player $player): int {
        $xboxId = $player->getXuid();
        if(!isset($this->ids[$xboxId])) {
            $this->ids[$xboxId] = $this->id++;
        }
        return $this->ids[$xboxId];
    }

    public function resetIds(): void {
        $this->id = 0;
        $this->ids = [];
    }
}