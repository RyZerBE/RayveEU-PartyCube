<?php

declare(strict_types=1);

namespace rayveeu\partycube\util\ranking;

class HighestPointsRanking extends Ranking{
    public function makeList(): array{
        $list = [];
        foreach($this->points as $xboxId => $countable) {
            $list[$xboxId] = $countable->get();
        }
        arsort($list);
        return $list;
    }
}