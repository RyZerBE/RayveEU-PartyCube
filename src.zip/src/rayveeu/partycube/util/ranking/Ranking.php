<?php

declare(strict_types=1);

namespace rayveeu\partycube\util\ranking;

use pocketmine\player\Player;
use rayveeu\essentials\player\Session;
use rayveeu\essentials\util\Countable;

abstract class Ranking{
    /** @var Countable[] */
    protected array $points = [];

    protected array $list = [];
    protected array $fixedPlacements = [];

    protected int $placement = 0;

    private bool $changed = true;

    public function getPoints(Player $player): Countable{
        $xboxId = $player->getXuid();
        $this->changed = true;
        return $this->points[$xboxId] ??= new Countable();
    }

    abstract public function makeList(): array;

    public function getList(): array {
        if($this->changed) {
            $this->list = $this->makeList();
            $this->changed = false;
        }
        return $this->list;
    }

    public function fixPlacement(Player $player): void {
        $this->fixedPlacements[$player->getXuid()] = ++$this->placement;
        $this->getPoints($player)->set(-1);
    }

    public function getPlacement(Player $player): int {
        $session = Session::getNullSafe($player);
        $displayName = $session->getDisplayName();
        $last = 0;
        foreach($this->getPlacements() as $placement => $players) {
            $last = $placement;
            foreach($players as $name) {
                if($name === $displayName) {
                    return $placement;
                }
            }
        }
        return ++$last;
    }

    public function getPlacements(): array {
        $list = [];
        $placement = $this->placement;
        $lastPoints = PHP_INT_MIN;

        foreach($this->getList() as $xboxId => $points) {
            $session = Session::get((string)$xboxId);
            if($session === null) {
                continue;
            }
            if(isset($this->fixedPlacements[$xboxId])) {
                $list[$this->fixedPlacements[$xboxId]][] = $session->getDisplayName();
                continue;
            }
            if($lastPoints !== $points) {
                $placement++;
                $lastPoints = $points;
            }
            $list[$placement][] = $session->getDisplayName();
        }
        ksort($list);
        return $list;
    }
}